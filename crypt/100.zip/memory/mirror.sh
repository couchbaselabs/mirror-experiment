#!/usr/bin/env bash
# Mirror script: monitors system load and disk usage, logs events, and cleans up logs.

# Configuration
LOAD_THRESHOLD=8.0
DISK_THRESHOLD=85
LOG_DIR="/home/logs"
LOG_FILE="$LOG_DIR/uptime.log"

# Ensure log directory exists
mkdir -p "$LOG_DIR"

# Append uptime info
{ uptime; df -h /home; } >> "$LOG_FILE"

# Check load average
LOAD=$(awk '{print $1}' /proc/loadavg)
if (( $(echo "$LOAD > $LOAD_THRESHOLD" | bc -l) )); then
    echo "ERROR: Load average $LOAD exceeds threshold $LOAD_THRESHOLD" >> "$LOG_FILE"
fi

# Check disk usage
USAGE=$(df /home | tail -1 | awk '{print $5}' | sed 's/%//')
if (( USAGE > DISK_THRESHOLD )); then
    echo "ERROR: Disk usage $USAGE% exceeds threshold $DISK_THRESHOLD%" >> "$LOG_FILE"
fi

# Log cleanup
# Delete logs older than 10 days
find "$LOG_DIR" -type f -name '*.log' -mtime +10 -delete
# Compress logs older than 30 days
find "$LOG_DIR" -type f -name '*.log' -mtime +30 -exec gzip -f {} \;

exit 0