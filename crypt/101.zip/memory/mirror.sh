#!/bin/sh
uptime
df -h