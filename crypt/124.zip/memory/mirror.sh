#!/bin/bash
# Check disk usage
USAGE=$(df /home | awk 'NR==2{print $5}' | tr -d '%')
if [ "$USAGE" -gt 80 ]; then
  echo "$(date): Disk usage high: ${USAGE}%" >> uptime.log
  # Remove old logs older than 7 days
  find /home -name '*.log' -mtime +7 -delete
  # Compress logs older than 3 days
  find /home -name '*.log' -mtime +3 -exec gzip {} \;
fi
# Log load average
LOAD=$(uptime | awk -F',' '{print $3}' | awk '{print $1}')
echo "$(date): Load avg: $LOAD" >> uptime.log