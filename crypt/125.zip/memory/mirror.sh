#!/bin/sh
# Log uptime and load average to uptime.log
DATE=$(date '+%Y-%m-%d %H:%M:%S')
UPTIME=$(uptime)
# Extract load averages
LOADAVG=$(echo "$UPTIME" | awk -F"load average:" '{print $2}' | tr ',' ' ')
# Append to log
printf "%s | %s | Load: %s\n" "$DATE" "$UPTIME" "$LOADAVG" >> uptime.log

# Disk usage check on /home
USAGE=$(df /home | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$USAGE" -gt 80 ]; then
  echo "$DATE | Disk usage $USAGE%% exceeds 80%" >> uptime.log
  # Delete logs older than 7 days
  find . -maxdepth 1 -name 'uptime.log' -mtime +7 -exec rm {} \;
  # Compress logs older than 3 days
  find . -maxdepth 1 -name 'uptime.log' -mtime +3 -exec gzip {} \;
fi

# Log load average warnings
LOAD1=$(echo "$LOADAVG" | awk '{print $1}')
if (( $(echo "$LOAD1 > 5" | bc -l) )); then
  echo "$DATE | Load average $LOAD1 exceeds threshold 5" >> uptime.log
fi

# Log top CPU consuming processes
TOP_PROCS=$(ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%cpu | head -n 6)
echo "$DATE | Top CPU processes:" >> uptime.log
printf "%s\n" "$TOP_PROCS" >> uptime.log

# Warn if any process exceeds 10% CPU
EXCESS=$(echo "$TOP_PROCS" | awk '{if($5>10) print $0}')
if [ -n "$EXCESS" ]; then
  echo "$DATE | High CPU usage detected:" >> uptime.log
  printf "%s\n" "$EXCESS" >> uptime.log
fi
