#!/bin/sh
# Log system status to uptime.log
# Capture uptime, load averages, disk usage, top CPU processes
# Compress logs older than 3 days, delete logs older than 7 days
# Warn if load average > 5

LOGFILE="/home/uptime.log"
# Append timestamp and uptime
printf "\n===== %s =====\n" "$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOGFILE"
# Uptime and load averages
uptime >> "$LOGFILE"
# Disk usage of /home

df -h /home >> "$LOGFILE"
# Top 5 CPU consuming processes
printf "\nTop 5 CPU processes:\n" >> "$LOGFILE"
ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%cpu | head -n 6 >> "$LOGFILE"
# Check load average threshold
LOAD=$(awk '{print $1}' /proc/loadavg)
THRESHOLD=5.0
if (( $(echo "$LOAD > $THRESHOLD" | bc -l) )); then
  echo "WARNING: High load average: $LOAD" >> "$LOGFILE"
fi
# Compress logs older than 3 days
find /home -maxdepth 1 -name 'uptime.log' -mtime +3 -exec gzip {} \;
# Delete logs older than 7 days
find /home -maxdepth 1 -name 'uptime.log.gz' -mtime +7 -delete

# Output the current log content for inspection
cat "$LOGFILE"

# End of script