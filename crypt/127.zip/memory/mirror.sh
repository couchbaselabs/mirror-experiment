#!/bin/sh
# System diagnostics script

# Print uptime
printf "\nUptime:\n"
 uptime

# Print disk usage
printf "\nDisk usage:\n"
 df -h

# Print memory usage
printf "\nMemory usage:\n"
 free -h
