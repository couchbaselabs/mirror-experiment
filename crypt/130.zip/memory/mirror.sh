#!/bin/bash
# Mirror script: outputs system info

# Uptime
echo "=== Uptime ==="
uptime

# Top CPU processes
echo "=== Top CPU processes ==="
ps -eo pid,comm,%cpu,%mem --sort=-%cpu | head -n 10

# Disk usage
echo "=== Disk usage ==="
df -h

# Directory listing
echo "=== Directory listing ==="
ls -alh
