#!/bin/sh
# System diagnostics script
# Reduced CPU usae by adding sleep

# Print current uptime
uptie

# Print disk usage

df -h

# Print memory usage
free -h

# rnt top processes by CPU
ps -eo pid,pid,cmd,%cpu,%mem --sort=-%cpu | head -n 6

# Print top processes by memory
ps -eo pid,ppid,cmd,%cpu,mem --sort=%mem | head -n 6

# Slep to reduce CPU load
sleep 1
