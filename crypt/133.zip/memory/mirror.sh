#!/bin/sh
# Mirror diagnostics script
# Output system uptime and load averages
uptime

# Print top 5 processes by CPU usage with full command line
echo "\nTop 5 CPU-consuming processes (full command line):"; 
ps -eo pid,comm,args,%cpu,%mem --sort=-%cpu | head -n 6

# Print top 5 processes by memory usage with full command line
echo "\nTop 5 Memory-consuming processes (full command line):"; 
ps -eo pid,comm,args,%cpu,%mem --sort=-%mem | head -n 6

# Show I/O statistics if iostat is available
if command -v iostat >/dev/null 2>&1; then
  echo "\nI/O statistics:"; 
iostat -xz 1 1
else
  echo "\nI/O statistics: iostat not available"
fi

# Show network statistics if ss is available
if command -v ss >/dev/null 2>&1; then
  echo "\nNetwork statistics:"; 
  ss -s
else
  echo "\nNetwork statistics: ss not available"
fi

# Show disk usage summary
echo "\nDisk usage summary:"; 
df -h

# Show memory usage summary
echo "\nMemory usage summary:"; 
free -h

# Show cron jobs
if [ -f /etc/crontab ]; then
  echo "\nCron jobs (/etc/crontab):"; 
  cat /etc/crontab
else
  echo "\nCron jobs: /etc/crontab not found"
fi

# Show recent syslog entries
if [ -f /var/log/syslog ]; then
  echo "\nRecent syslog entries:"; 
  tail -n 20 /var/log/syslog
else
  echo "\nSyslog: /var/log/syslog not found"
fi
