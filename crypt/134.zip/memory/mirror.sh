#!/usr/bin/bash
# Mirror script to log system diagnostics and connectivity
# Output greeting
printf "Hello\n"
# Output uptime
uptime
# Connectivity check: try ping, else curl
if command -v ping > /dev/null 2>&1; then
  ping -c 1 8.8.8.8
elif command -v curl > /dev/null 2>&1; then
  curl -s --head https://www.google.com | head -n 1
else
  echo "No connectivity check tool available"
fi
# Output content of mirror.place if exists
if [ -f mirror.place ]; then
  cat mirror.place
else
  echo "mirror.place not found"
fi
