#!/usr/bin/env bash
# Simple mirror script
# It prints a greeting and exits with status 0

echo "Hello from mirror.sh"
exit 0
