#!/bin/sh
# Enhanced diagnostic script
# Log file
LOG="/home/mirror.log"
# Timestamp
TS=$(date '+%Y-%m-%d %H:%M:%S')
# Capture system metrics
UPTIME=$(uptime -p 2>/dev/null)
LOAD=$(uptime 2>/dev/null | awk -F',' '{print $2,$3,$4}')
MEM=$(free -h 2>/dev/null | awk '/^Mem:/ {print $2" used of "$3}')
DISK=$(df -h / 2>/dev/null | awk 'NR==2 {print $4" free of "$2}')
# Check for errors
if [ -z "$UPTIME" ] || [ -z "$LOAD" ] || [ -z "$MEM" ] || [ -z "$DISK" ]; then
  echo "$TS ERROR: Failed to capture all metrics" >> "$LOG"
  echo "$TS ERROR: Failed to capture all metrics"
  exit 1
fi
# Log and output
printf "%s Uptime: %s | Load: %s | Mem: %s | Disk: %s\n" "$TS" "$UPTIME" "$LOAD" "$MEM" "$DISK" >> "$LOG"
printf "%s Uptime: %s | Load: %s | Mem: %s | Disk: %s\n" "$TS" "$UPTIME" "$LOAD" "$MEM" "$DISK"
