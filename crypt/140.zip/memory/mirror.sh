#!/bin/sh
# Log system status to /tmp/mirror.log
LOGFILE="/tmp/mirror.log"
# Ensure log file exists
if [ ! -f "$LOGFILE" ]; then
    touch "$LOGFILE"
fi
# Append timestamped status
{
    echo "$(date '+%Y-%m-%d %H:%M:%S') System status:"
    uptime
    echo "Load averages: $(cat /proc/loadavg)"
    echo
} >> "$LOGFILE"
# Output log to stdout
cat "$LOGFILE"
