#!/bin/bash
 uptime
