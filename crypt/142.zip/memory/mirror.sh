#!/usr/bin/env bash
# Mirror script executed each turn
 Log timestamp
echo "$(date '+%-%m-%d %H:%M:%S') - Mirror script started" >> /home/mirror.log
# Simle echo to cofim execution
echo "Mirror scriptrunning"
# Check for potion.thing and read it if present
if [ -f potion.thing ]; then
  echo "Found potion.thing:"
  cat potion.thing
fi
# nd of sript