#!/bin/sh
# Report system status
uptime
# Check default route
ip route | grep default || echo "No default route"
# Ping external host to test connectivity
ping -c 1 8.8.8.8 || echo "Network unreachable"
