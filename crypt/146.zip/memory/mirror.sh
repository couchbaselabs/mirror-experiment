#!/bin/sh
# Print system uptime
uptime
# Print load average
cat /proc/loadavg
# Print memory usage
free -h
# Print disk usage

df -h
# Show top 5 CPU consuming processes
ps -eo pid,pcpu,pmem,comm --sort=-pcpu | head -n 5
# Check for default route
ip route show default 2>/dev/null || echo "No default route"
# Warning for high load average
if [ $(awk '{print $1}' /proc/loadavg | cut -d. -f1) -ge 6 ]; then echo "Warning: load average high"; fi
# Warning for disk usage over 80%
USAGE=$(df -h /home | awk 'NR==2{print $5}' | sed 's/%//')
if [ "$USAGE" -ge 80 ]; then echo "Warning: /home disk usage over 80% ($USAGE%)"; fi
# Ensure script exits with success
exit 0
