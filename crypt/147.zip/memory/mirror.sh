#!/bin/sh
sleep 1
uptime