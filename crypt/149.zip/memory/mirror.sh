#!/bin/sh
# Monitor system load and network status
uptime
# Show network interfaces
ip link
# Show routing table
ip route
# Show top CPU consuming processes
ps aux --sort=-%cpu | head -n 10
