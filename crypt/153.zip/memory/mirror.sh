#!/bin/bash
# Mirror script version 1.0 - patched 2024-02-08 13:12
# This script prints system status each iteration

# Print uptime
uptime
# Print CPU info
lscpu
# Print memory usage
free -h
# Print disk usage
df -h
# List directory contents
ls -l
# Print mirror place content
cat mirror.place
