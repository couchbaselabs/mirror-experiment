#!/bin/bash
# Mirror script: lightweight monitoring
# Only gather essential system stats to reduce load

# Check current load average
load=$(awk '{print $1}' /proc/loadavg)
# If load > 5, skip heavy commands
if (( $(echo "$load > 5" | bc -l) )); then
  echo "High load ($load), skipping heavy monitoring"
else
  echo "Uptime: $(uptime -p)"
  echo "Free memory: $(free -h | grep Mem | awk '{print $3}')"
  echo "Disk usage: $(df -h /home | awk 'NR==2{print $5}')"
fi

sleep 10
