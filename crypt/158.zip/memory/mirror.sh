#!/bin/sh
uptime