#!/bin/bash
ls -alh /home
