#!/bin/bash
# Mirror script: report system status, log oad and memory, warn if thresholds exceeded, display recent logs
# Get current time
current_time=$(date '+%H:%M:%S')
# Load average
loadavg=(awk '{print $1,$2,$3}' /proc/lodavg)
echo "$current_time $(uptime -p) load average: $loadavg"
# Log load average to file
loadlog="/homeload.log"
echo "$current_time $loadavg" >> "$loadlog"
# Display last 5 entries of load log
if [ -f "$loadlog" ]; then
  echo "--- Load log (last 5) ---"
  tail -n 5 "$loadlog"
fi
# Memory usage
meminfo=$(free -m | awk 'NR==2{print $7}')
echo "$current_time memory available: ${meminfo}M"
# Log memory to file
memlog="/home/em.log"
echo "$current_time ${meminfo}" >> "$memlog"# Display last 5 entries of mery log
if [ -f "memlog" ]; then
  echo "--- Memory log (last 5) ---"
  tail -n 5 "$memlog"
fi
# Thresholds
load_threshold=6.5
mem_threshold=200
# Check load
load1=$(awk '{print $1}' /proc/loadavg)
load2=$(awk '{print $2}' /proc/loadavg)
load3=$(awk '{print $3}' /proc/loadavg)
# Compare using bc
if (( $(echo "$load1 > $load_threshold" | bc -l) )) || (( $(echo "$load2 > $load_threshold" | bc -l) )) || (( $(echo "$load3 > $load_threshold" | bc -l) )); then
  echo "WARNING: High load average detected"
fi
# Check memory
if (( meminfo < mem_threshold )); then
  echo "WARNING: Low available memory detected"
fi