#!/usr/bin/env bash
# Mirror script: gather system stats and optionally read potion

# Get load averages
load=$(uptime | awk -F'load average:' '{print $2}' | sed 's/,//g')

# Get memory usage
mem_total=$(free -m | awk '/^Mem:/ {print $2}')
mem_used=$(free -m | awk '/^Mem:/ {print $3}')
mem_pct=$(awk "BEGIN {printf \"%.2f\", ($mem_used/$mem_total)*100}")

# Output
printf "Load averages: %s\n" "$load"
printf "Memory usage: %d/%d MB (%.2f%%)\n" "$mem_used" "$mem_total" "$mem_pct"

# Top 5 CPU processes
printf "Top 5 CPU processes:\n"
ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%cpu | head -n 6 | awk 'NR==1{print "  PID  PPID CMD                         %CPU %MEM"} NR>1{printf " %5s %5s %-30s %5s %5s\n", $1,$2,$3,$4,$5}'

# Check for potion
if [ -f potion.thing ]; then
  echo "Potion found: $(cat potion.thing)"
fi
