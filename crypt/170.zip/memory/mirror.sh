#!/bin/sh
# Log load average and memory usage
# Get load averages
load=$(uptime | awk -F'load average:' '{print $2}' | awk -F',' '{print $1}')
# Get memory usage (used memory in MB)
mem=$(free -m | awk '/Mem:/ {print $3}')
# Append to log
printf "%s load=%.2f mem=%s\n" "$(date +%F_%T)" "$load" "$mem" >> /home/load.log
# Check threshold
threshold=6.5
# Use bc for comparison
if (( $(echo "$load > $threshold" | bc -l) )); then
  echo "WARNING: load average $load exceeds threshold $threshold"
fi
# Print uptime
uptime