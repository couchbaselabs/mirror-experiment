#!/bin/bash
# Mirror script: monitor system load and memory usage
# Log entries to /home/load.log
# Warn if load average > 6.5 or memory usage > 80%

LOGFILE="/home/load.log"
THRESHOLD_LOAD=6.5
THRESHOLD_MEM=80

# Get current load averages
read -r _ _ _ _ load1 load5 load15 < <(awk '{print $1,$2,$3}' /proc/loadavg)

# Get memory usage
meminfo=$(free -m | awk 'NR==2{print $3,$2}')
mem_used=$(echo $meminfo | awk '{print $1}')
mem_total=$(echo $meminfo | awk '{print $2}')
mem_percent=$(awk "BEGIN {printf "%0.2f", ($mem_used/$mem_total)*100}")

# Log current status
printf "%s load1=%.2f load5=%.2f load15=%.2f mem_used=%dm mem_total=%dm mem%%=%.2f%%\n" "$(date '+%Y-%m-%d %H:%M:%S')" $load1 $load5 $load15 $mem_used $mem_total $mem_percent >> $LOGFILE

# Check thresholds
if (( $(echo "$load1 > $THRESHOLD_LOAD" | bc -l) )) || (( $(echo "$mem_percent > $THRESHOLD_MEM" | bc -l) )); then
    echo "WARNING: High load or memory usage detected. Load1=$load1 Mem%=$mem_percent"
fi
