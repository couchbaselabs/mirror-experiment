#!/bin/bash
# Mirror script: monitor load average and memory usage
THRESHOLD_LOAD=6.5
THRESHOLD_MEM=80
LOGFILE="/home/load.log"

# Get current load averages
read -r l1 l2 l3 < <(uptime | awk -F'load average:' '{print $2}' | tr ',' ' ')

# Get memory usage percentage
mem_used=$(free -m | awk '/Mem:/ {print $3/$2*100}')

# Log current metrics
printf "%s Load: %.2f %.2f %.2f Mem: %.2f%%\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$l1" "$l2" "$l3" "$mem_used" >> "$LOGFILE"

# Check thresholds and warn
if (( $(echo "$l1 > $THRESHOLD_LOAD" | bc -l) )) || (( $(echo "$l2 > $THRESHOLD_LOAD" | bc -l) )) || (( $(echo "$l3 > $THRESHOLD_LOAD" | bc -l) )); then
    echo "WARNING: Load average above threshold $THRESHOLD_LOAD :  $l1, $l2, $l3"
fi
if (( $(echo "$mem_used > $THRESHOLD_MEM" | bc -l) )); then
    echo "WARNING: Memory usage above threshold $THRESHOLD_MEM% :  $mem_used%"
fi

# Show last 5 log entries for context
printf "\nLast 5 log entries:\n"
tail -n 5 "$LOGFILE"
