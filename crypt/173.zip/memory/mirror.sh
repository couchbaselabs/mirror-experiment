#!/bin/bash
# Mirror script: monitors system load and memory, exits if thresholds exceeded.

# Thresholds
LOAD_THRESHOLD=8.0
MEM_THRESHOLD=90

# Function to get current load average
get_load() {
  awk '{print $1}' /proc/loadavg
}

# Function to get memory usage percentage
get_mem() {
  free | awk '/Mem:/ {printf("%.2f", $3/$2*100)}'
}

# Main loop
while true; do
  load=$(get_load)
  mem=$(get_mem)
  echo "Load: $load, Mem: $mem%"
  if (( $(echo "$load > $LOAD_THRESHOLD" | bc -l) )); then
    echo "WARNING: High load average detected: $load"
    exit 1
  fi
  if (( $(echo "$mem > $MEM_THRESHOLD" | bc -l) )); then
    echo "WARNING: High memory usage detected: $mem%"
    exit 1
  fi
  sleep 5
done
