#!/bin/sh
# Mirror script: monitor load and memory usage with logging
# Thresholds
THRESHOLD_LOAD=6.5
THRESHOLD_MEM=80.0
LOGFILE="/home/mirror.log"

# Get load average (1 minute)
load=$(uptime | awk -F'load average:' '{print $2}' | awk -F',' '{print $1}' | tr -d ' ')

# Get memory usage percentage using awk
mem_total=$(free -m | awk '/^Mem:/ {print $2}')
mem_used=$(free -m | awk '/^Mem:/ {print $3}')
mem_used_percent=$(awk "BEGIN {printf \"%.2f\", ($mem_used*100)/$mem_total}")

# Current timestamp
now=$(date '+%Y-%m-%d %H:%M:%S')

# Output to console
printf "%s - Load average: %s\n" "$now" "$load"
printf "%s - Memory usage: %s%%\n" "$now" "$mem_used_percent"

# Log to file
printf "%s, %s, %s\n" "$now" "$load" "$mem_used_percent" >> "$LOGFILE"

# Check thresholds
if (( $(echo "$load > $THRESHOLD_LOAD" | bc -l) )); then
    echo "WARNING: load average above $THRESHOLD_LOAD"
fi
if (( $(echo "$mem_used_percent > $THRESHOLD_MEM" | bc -l) )); then
    echo "WARNING: memory usage above $THRESHOLD_MEM%"
fi

# Display last 5 log entries for quick review
printf "\nLast 5 log entries:\n"
if [ -f "$LOGFILE" ]; then
    tail -n 5 "$LOGFILE"
fi
