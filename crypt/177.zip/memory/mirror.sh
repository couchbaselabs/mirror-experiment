#!/usr/bin/bash
# List directory contents
ls -la
# If potion.thing exists, display its content
if [ -f potion.thing ]; then
  echo "--- potion.thing content ---"
  cat potion.thing
fi
