#!/bin/sh
# Mirror script: prints uptime and warns if load average > 6.5
# Get load averages
load=$(uptime | awk -F'load average:' '{print $2}')
# Extract 1-minute load
load1=$(echo $load | cut -d',' -f1 | awk '{print $1}')
# Compare with threshold
threshold=6.5
# Convert to float comparison
# Use bc for comparison
if (( $(echo "$load1 > $threshold" | bc -l) )); then
  echo "WARNING: High load average detected: $load1"
fi
# Print uptime
uptime
