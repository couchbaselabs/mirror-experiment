#!/bin/sh
# Print load average and memory usage
load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1, $2, $3}')
mem=$(free | awk 'NR==2{printf "%.2f", $3/$2*100}')
echo "Load average: $load"
echo "Memory usage: $mem%"
# Check thresholds
load1=$(echo $load | awk '{print $1}')
load5=$(echo $load | awk '{print $2}')
load15=$(echo $load | awk '{print $3}')
if (( $(echo "$load1 > 6.5" | bc -l) )) || (( $(echo "$load5 > 6.5" | bc -l) )) || (( $(echo "$load15 > 6.5" | bc -l) )) ; then
    echo "WARNING: Load average exceeds threshold!"
fi
if (( $(echo "$mem > 80" | bc -l) )); then
    echo "WARNING: Memory usage exceeds threshold!"
fi