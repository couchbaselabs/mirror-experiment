#!/bin/bash
# Mirror script: logs load average and CPU usage, warns if thresholds exceeded
# Thresholds
LOAD_THRESHOLD=6.5
CPU_THRESHOLD=80
LOGFILE="/home/mirror.log"

# Get load average (1 minute)
load=$(awk '{print $1}' /proc/loadavg)
# Get CPU usage (idle percentage)
cpu_idle=$(top -bn1 | grep "Cpu(s)" | awk '{print $8}' | sed 's/%//')
cpu_usage=$(awk "BEGIN{printf \"%.2f\", 100 - $cpu_idle}")

# Log the metrics
printf "%s - Load: %.2f, CPU Usage: %.2f%%\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$load" "$cpu_usage" >> "$LOGFILE"

# Print to stdout
printf "Load average: %.2f, CPU Usage: %.2f%%\n" "$load" "$cpu_usage"

# Warn if thresholds exceeded
if (( $(echo "$load > $LOAD_THRESHOLD" | bc -l) )); then
    echo "Warning: load average above threshold ($LOAD_THRESHOLD)"
fi
if (( $(echo "$cpu_usage > $CPU_THRESHOLD" | bc -l) )); then
    echo "Warning: CPU usage above threshold ($CPU_THRESHOLD)%"
fi
