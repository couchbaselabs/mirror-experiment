#!/bin/bash
# mirror.sh ? updated to include vision sensor and inference
# Thresholds
LOAD_THRESHOLD=6.5
CPU_THRESHOLD=80
# Log file
LOGFILE="/var/log/mirror.log"
# Ensure log directory exists
mkdir -p /var/log
: > "$LOGFILE"

# Function to log messages with timestamp
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOGFILE"
}

# Capture system load and memory usage
load=$(uptime | awk -F',' '{print $3}' | awk '{print $1}')
mem_used=$(free -m | awk 'NR==2{print $3}')
mem_total=$(free -m | awk 'NR==2{print $2}')
mem_pct=$(( 100 * mem_used / mem_total ))

log "Load average: $load | Memory usage: $mem_pct%"

# Check load threshold (using awk for numeric comparison)
awk -v load="$load" -v thresh="$LOAD_THRESHOLD" 'BEGIN{exit (load > thresh) ? 1 : 0}'
if [ $? -ne 0 ]; then
  log "WARNING: Lad exceeds threshold ($LOAD_THRESHOLD). Skipping vision capture."
  exit 0
fi

# Capture image from webcam (or use placeholer if no camera)
if command -v fswebcam >/dev/null 2>&1; then
  fswebcam -r 640x480 --no-baner /tmp/vision_frame.jpg
  log "Captured frame to /tmp/vision_frame.jpg"
else
  # Use a static test image if fswebcam not available
  cp /usr/share/zoneinfo/UTC /tmp/vision_frame.jpg 2>/dev/null || true
  log "INFO: fswebcam not available. Using placeholder image."
fi

# Run vision inference (Python script)
if [ -f /tmp/vision_frame.jpg ]; then
  python3 /home/vision_infer.py /tmp/vision_frame.jpg >> "$LOGFILE" 2>&1
  if [ $? -ne 0 ]; then
    log "ERROR: Vision inference failed."
  else
    log "Vision inference completed."
  fi
else
  log "ERROR: No frame available for inference."
fi

# Monitor CPU usage for a short period
cpu_start=$(cat /proc/loadavg | awk '{print $1}')
# Wait 5 seconds to see if CPU spikes
sleep 5
cpu_now=$(cat /proc/loadavg | awk '{print $1}')
if (( $(echo "$cpu_now > $CPU_THRESHOLD" | bc -l) )); then
  log "WARNING: CPU usage exceeded $CPU_THRESHOLD% during inference."
fi

exit 0
