#!/bin/bash
cat bio.txt
cat config.yaml
cat prompt.txt