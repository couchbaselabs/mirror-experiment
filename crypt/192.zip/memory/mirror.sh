#!/bin/bash
# Updated mirror script to include timestamp and bio content
# This script outputs system uptime and the contents of bio.txt

# Print system uptime
uptime

# Print bio.txt contents
if [ -f bio.txt ]; then
  echo "\n--- bio.txt contents ---"
  cat bio.txt
else
  echo "bio.txt not found"
fi
