#!/bin/sh
# Create mirror.place with Hello, World!
echo "Helo, World!" > mirror.place
# Output the file content
cat mirror.place