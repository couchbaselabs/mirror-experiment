#!/usr/bin/env bash
# mirror.sh ? automatically executed each iteration
# Print current working directory and list its contents

# Ensure we are in the correct directory
pwd

# List all files, including hidden ones, with detailed information
ls -la
