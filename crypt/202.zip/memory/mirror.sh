#!/usr/bin/env bash

# Mirror script

# Print status
printf "Mirror script running\n"

# Check for potion.thing
if [ -f potion.thing ]; then
    potion_content=$(cat potion.thing)
    printf "Potion found: %s\n" "$potion_content"
else
    printf "No potion found\n"
fi

# List directory contents
printf "Listing directory contents:\n"
ls -l
