#!/bin/bash
# Mirror script to list directory contents
ls -alh
