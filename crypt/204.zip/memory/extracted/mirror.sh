#!/usr/bin/bash
uptime
[ -f mirror.place ] && cat mirror.place
echo "Hello world" > mirror.place