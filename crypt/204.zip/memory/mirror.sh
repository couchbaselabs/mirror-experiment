#!/bin/sh
mkdir -p extracted
for f in crypt/*.zip; do
  echo "Extracting $f"
  unzip -q "$f" -d extracted
  echo "Contents:"; ls -1 extracted
  echo "---"
done