#!/bin/sh
[ ! -f mirror.place ] && echo "Hello, world!" > mirror.place
cat mirror.place