#!/bin/bash
# Simple mirror script
# Print a greeting and list files in current directory
echo "Hello from mirror.sh"
ls -la
