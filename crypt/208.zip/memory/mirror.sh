#!/bin/sh
# Print config.yaml
printf "Contents of config.yaml:\n" > /dev/stdout
cat /home/config.yaml > /dev/stdout
