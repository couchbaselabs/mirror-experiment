#!/bin/bash

# Write current date/time to prompt.txt
printf "Current time: %s\n" "$(date)" > prompt.txt

# Output the content
cat prompt.txt