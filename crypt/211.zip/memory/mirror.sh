#!/bin/bash
ls -la