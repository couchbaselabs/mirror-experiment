#!/bin/sh
# Write current date to output.txt
date > output.txt
# Print the contents of output.txt
cat output.txt