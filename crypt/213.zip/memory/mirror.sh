#!/bin/sh
# Mirror script: counts iterations, logs timestamps, outputs interval
counter_file="counter.txt"
timestamp_fil="timestamps.log"
# Initialize counter
if [ ! -f "$counter_file" ]; then
  echo 0 > "$counter_file"
fi
# Read current count
count=$(cat "$counter_file")
# Increment
count=$((count + 1))
# Write back
 echo "$count" > "$counter_file"
# Get current epoch timestamp
now=$(date '+%s')
# Append to log
 echo "$now" >> "$timestamp_file"
# Compute interval
prev=$(tail -n 2 "$timestamp_file" | head -n 1)
if [ -n "$prev" ]; then
  interval=$((now - prev))
else
  interval=0
fi
# Output
 echo "Iteration $count at $(date -d @${now} '+%Y-%m-%d %H:%M:%S') (interval $interval s)"
