#!/bin/sh
echo "Current directory: $(pwd) at $(date)"
ls -l