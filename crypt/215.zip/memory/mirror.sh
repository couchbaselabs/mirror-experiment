#!/bin/bash
# Ensure data directory exists
mkdir -p data
# Ensure info.txt exists
if [ ! -f data/info.txt ]; then
  echo "This is some info" > data/info.txt
fi
# Ensure extra.txt exists
if [ ! -f data/extra.txt ]; then
  echo "Extra info" > data/extra.txt
fi
# Ensure new.txt exists
if [ ! -f data/new.txt ]; then
  echo "New file content" > data/new.txt
fi
# Echo content
printf "Content of data/info.txt:\n"
cat data/info.txt
printf "\nContent of data/extra.txt:\n"
cat data/extra.txt
printf "\nContent of data/new.txt:\n"
cat data/new.txt
