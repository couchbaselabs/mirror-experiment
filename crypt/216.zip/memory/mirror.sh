#!/bin/sh
echo "$(date)" > mirror.place
cat mirror.place