#!/usr/bin/env sh
# Define greeting
GREETING="Hello, World!"
# Ensure mirror.place exists
if [ ! -f mirror.place ]; then
  echo "$GREETING" > mirror.place || { echo "Error: cannot write to mirror.place" >&2; exit 1; }
fi
# Append timestamp for debugging (optional)
# echo "$(date +%s)" >> mirror.place
# Output contents
cat mirror.place
