#!/bin/sh
# Script to write the current date to date.txt

echo "Current date and time: $(date)" > date.txt
cat date.txt