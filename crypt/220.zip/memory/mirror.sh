#!/bin/sh

echo "Hello from mirror $(date)" > mirror.place
cat mirror.place