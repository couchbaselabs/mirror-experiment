#!/bin/bash
# Mirror script
# Print greeting and list current directory

echo "Hello from mirror script"
ls -la

# Display prompt.txt
cat prompt.txt

exit 0
