#!/bin/sh
if [ ! -f mirror.place ]; then
  echo "Hello, world!" > mirror.place
fi
cat mirror.place