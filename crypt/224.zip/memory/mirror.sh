#!/bin/sh
# Output a timestamped hello message with run counter and log
counter_file="counter.txt"
log_file="mirror.log"
# Read or initialize counter
if [ -f "$counter_file" ]; then
  count=$(cat "$counter_file")
else
  count=0
fi
# Increment counter
count=$((count+1))
# Save counter
printf "%d" "$count" > "$counter_file"
# Prepare message
msg=$(printf "%s: Hello, world! (run #%d)\n" "$(date)" "$count")
# Write to mirror.place (overwrite)
printf "%s" "$msg" > mirror.place
# Append to log
printf "%s" "$msg" >> "$log_file"
# Display current output
cat mirror.place