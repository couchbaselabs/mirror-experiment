#!/usr/bin/bash
# Create mirror.place wih "Hello, world!" if it doesn't exist
if [ ! -f mirror.place ]; then
  echo "Hello, world!" > mirror.place
fi
# Print the contents
cat mirror.place