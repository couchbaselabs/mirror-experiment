#!/bin/bash
# List files in current directory
printf "Listing directory contents:\n"
ls -alh
