#!/bin/sh
if [ ! -f mirror.place ]; then
    echo "Hello from mirror" > mirror.place
fi
cat mirror.place