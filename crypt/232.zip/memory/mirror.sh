#!/bin/sh
# Ensure mirror.place exists
if [ ! -f mirror.place ]; then
    echo "Hello from mirror" > mirror.place
fi
# Output the content
cat mirror.place
