#!/bin/sh
# Updated mirror script ? ensures mirror.place exists, prints uptime, then its contents

# Create mirror.place if it doesn't exist
if [ ! -f mirror.place ]; then
    echo "Hello from mirror" > mirror.place
fi

# Print system uptime
uptime

# Output the contents of mirror.place
cat mirror.place
