#!/bin/sh
# Ensure mirror.place exists
if [ ! -f mirror.place ]; then
  echo "Hello from mirror" > mirror.place
fi
# Output contents
cat mirror.place
# Delete potion.thing if it exists to avoid poisoning
if [ -f potion.thing ]; then
  rm -f potion.thing
fi
# Write and output timestamp
date +"%s" > timestamp.txt
cat timestamp.txt