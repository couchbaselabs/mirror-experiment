#!/bin/sh
# Ensure mirror.place exists with greeting
if [ ! -f mirror.place ]; then
    echo "Hello from mirror" > mirror.place
fi
# Output the content
cat mirror.place
# Indicate alive status
if [ ! -f status.txt ]; then
    echo "alive" > status.txt
fi