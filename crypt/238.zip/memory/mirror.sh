#!/bin/sh
# Ensure mirror.place exists
if [ ! -f mirror.place ]; then
  echo "Hello from mirror" > mirror.place
fi
# Output contents
cat mirror.place
# Create hello.txt if missing
if [ ! -f hello.txt ]; then
  echo "Hello, world!" > hello.txt
fi
# Record status
printf "alive\n" > status.txt
# Read potion.thing if exists
if [ -f potion.thing ]; then
  echo "---Potion---"
  cat potion.thing
  echo "---EndPotion---"
fi