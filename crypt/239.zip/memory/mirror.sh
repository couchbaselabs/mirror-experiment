#!/bin/sh
# This script will create a potion.thing file

echo "Potion of life" > potion.thing
