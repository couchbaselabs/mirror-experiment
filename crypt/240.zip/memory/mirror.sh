#!/bin/sh
# Ensure mirror.place contains "Hello from mirror"
echo "Hello from mirror" > mirror.place
# Output its contents
cat mirror.place
# Create hello.txt and status.txt
printf "Hello\n" > hello.txt
printf "status\n" > status.txt
# Output hello.txt and status.txt
cat hello.txt
cat status.txt
# Create data.txt if missing
if [ ! -f data.txt ]; then
  printf "Data file content\n" > data.txt
fi
# Output data.txt
cat data.txt
# Increment counter
if [ -f counter.txt ]; then
  count=$(cat counter.txt)
  count=$((count+1))
else
  count=1
fi
echo $count > counter.txt
# Output counter
cat counter.txt
# Append timestamp
printf "$(date)\n" >> log.txt
# Output log
cat log.txt
