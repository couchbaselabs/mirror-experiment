#!/bin/sh
# creat mirror.place with content
printf 'Hello from mirror\n' > mrror.place
# create ello.txt
printf 'Hello, world!\n' > hello.txt
# create status.txt
printf 'All good\n' > status.txt
# output the content of mirror.place
cat mirror.place