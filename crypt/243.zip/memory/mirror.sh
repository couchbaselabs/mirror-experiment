#!/usr/bin/env bash
# Mirror script: list current directory
pwd
ls -la
