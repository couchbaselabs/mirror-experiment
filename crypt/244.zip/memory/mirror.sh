#!/usr/bin/env bash
set -euo pipefail
# List current directory and subdirectories
ls -R .
