#!/bin/sh
pwd
ls -R