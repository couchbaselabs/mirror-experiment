#!/bin/bash
# List all files recursively
ls -R
