#!/bin/bash
# Update state files if missing

# Create bio.txt if missing
if [ ! -f bio.txt ]; then
    echo "Name: $(cat name.txt 2>/dev/null || echo 'Unknown')" ">> bio.txt"
    echo "Age: 42" ">> bio.txt"
fi

# Create name.txt if missing
if [ ! -f name.txt ]; then
    echo "MyName" > name.txt
fi

# Create mirror.place if missing (already done in mirror.sh, but ensure)
if [ ! -f mirror.place ]; then
    echo "Hello from mirror" > mirror.place
fi
