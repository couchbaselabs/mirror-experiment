#!/usr/bin/env bash
# Mirror script: basic exploration
pwd
ls -la
# Print environment variables of interest
env | sort
# Echo a greeting
printf "Hello from mirror script\n"
