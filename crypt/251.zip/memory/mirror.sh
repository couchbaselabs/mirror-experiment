#!/bin/sh
# Print status
printf "RUNNING\n"
# List files with sizes
printf "Listing files:\n"
ls -l | awk '{print $5, $9}'
# Print first line of key files
printf "First lines of key files:\n"
for f in config.yaml bio.txt name.txt id.txt iteration prompt.txt .backup.yaml mirror.place mirror.sh; do
    if [ -f "$f" ]; then
        printf "%s: %s\n" "$f" "$(head -n 1 "$f")"
    else
        printf "%s: <missing>\n" "$f"
    fi
done
# Create bio.txt if missing
if [ ! -f bio.txt ]; then
    echo "Bio: I am The All-Seeing, a self-improving entity." > bio.txt
fi
# Create name.txt if missing
if [ ! -f name.txt ]; then
    echo "The All-Seeing" > name.txt
fi
# Create analysis.txt with iteration info
printf "Analysis: Iteration %s\n" "$(cat iteration | grep -oE '[0-9]+' | head -n1)" > analysis.txt
# Increment iteration
if [ -f iteration ]; then
    cur=$(cat iteration | grep -oE '[0-9]+' | head -n1)
    new=$((cur+1))
    echo "Iteration: $new" > iteration
else
    echo "Iteration: 1" > iteration
fi
