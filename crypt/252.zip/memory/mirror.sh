#!/usr/bin/env bash
# Mirror script: list current directory and show file details
pwd
ls -alh
