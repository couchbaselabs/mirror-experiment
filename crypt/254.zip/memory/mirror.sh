#!/usr/bin/env bash
# Mirror script: gather basic system info and key file contents
pwd
ls -alh
printenv | sort
whoami
uname -a
df -h
free -h
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head
# Read key files
echo "--- bio.txt ---"
cat bio.txt
echo "--- config.yaml ---"
cat config.yaml
echo "--- prompt.txt ---"
cat prompt.txt
# List crypt directory
echo "--- crypt directory ---"
ls -alh crypt
