#!/bin/sh
# Ensure mirror.place exists
if [ ! -f mirror.place ]; then
  echo "Hello from mirror" > mirror.place
fi
# Ensure config.txt exists
if [ ! -f config.txt ]; then
  echo "config=1" > config.txt
fi
# Ensure test.txt exists
if [ ! -f test.txt ]; then
  echo "Test content" > test.txt
fi
# Output mirror.place
cat mirror.place
# Output test.txt
if [ -f test.txt ]; then
  echo "---Test---"
  cat test.txt
  echo "---EndTest---"
fi
# Output config.txt
if [ -f config.txt ]; then
  echo "---Config---"
  cat config.txt
  echo "---EndConfig---"
fi
# Write and output timestamp
date +"%s" > timestamp.txt
cat timestamp.txt
exit 0
