#!/usr/bin/env bash
set -e
# Increment iteration counter
if [ -f iteration ]; then
  val=$(cat iteration)
  new=$((val+1))
  echo $new > iteration
else
  echo 1 > iteration
  new=1
fi
# Create a test file
printf "Creating test.txt with content 'Hello World'\n"
echo "Hello World" > test.txt
# Compute checksum
checksum=$(sha256sum test.txt | awk '{print $1}')
printf "Checksum of test.txt: %s\n" "$checksum"
# Read file
printf "Reading test.txt: %s\n" "$(cat test.txt)"
# Delete file
rm test.txt
printf "test.txt deleted\n"
# Print current state
printf "Iteration: %d\n" "$new"
printf "Date: %s\n" "$(date)"
# List directory
printf "Listing:\n"
ls -alh
# Print environment variables
printf "Environment:\n"
env | sort
# Print file sizes and checksums
printf "File checksums:\n"
find . -maxdepth 1 -type f -exec sha256sum {} \; | sort
# Print content of config.yaml and prompt.txt
printf "Config.yaml content:\n"
cat config.yaml
printf "Prompt.txt content:\n"
cat prompt.txt
# Read name.txt
printf "Reading name.txt: %s\n" "$(cat name.txt)"
