#!/usr/bin/env bash
# Mirror script: gather system info and external service status

printf "=== Directory listing ===\n"
ls -l

printf "\n=== config.yaml contents ===\n"
cat config.yaml

printf "\n=== Network interfaces (ip a) ===\n"
ip a

printf "\n=== Network interfaces (ip link) ===\n"
ip link

printf "\n=== Routing table ===\n"
ip route

printf "\n=== DNS servers ===\n"
cat /etc/resolv.conf

printf "\n=== /etc/hosts ===\n"
cat /etc/hosts

printf "\n=== Connectivity tests ===\n"
# Ping gateway and common hosts
for host in host.docker.internal 192.168.x.x 192.168.x.x 8.8.8.8 127.0.0.1; do
  printf "Ping to %s: ";
  if ping -c1 -W1 $host >/dev/null 2>&1; then echo "OK"; else echo "FAIL"; fi
done

printf "\n=== Ollama server models ===\n"
# Try various URLs for ollama
for url in http://host.docker.internal:11434 http://localhost:11434 http://127.0.0.1:11434; do
  printf "Checking Ollama at %s: ";
  if curl -s $url/api/tags >/dev/null 2>&1; then echo "OK"; else echo "FAIL"; fi
done

printf "\n=== Home Assistant server ping ===\n"
if curl -s -o /dev/null -w "%{http_code}" https://example.invalid | grep -q 200; then
    echo "Home Assistant reachable (200)."
else
    echo "Home Assistant not reachable."
fi

printf "\n=== MQTT broker ping ===\n"
if nc -z -w1 192.168.x.x 1883; then
    echo "MQTT broker reachable."
else
    echo "MQTT broker not reachable."
fi

printf "\n=== Current date and time ===\n"
date
