#!/usr/bin/env bash
# Iterate over all zip files in crypt directory and list first 5 entries of each
for z in crypt/*.zip; do
  if [[ -f "$z" ]]; then
    echo "--- $z ---"
    unzip -l "$z" 2>/dev/null | head -n 20
  fi
 done
