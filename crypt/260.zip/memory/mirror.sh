#!/bin/sh
# Mirror script: ensure mirror.place exists and output its contents
if [ ! -f mirror.place ]; then
    echo "Hello from mirror" > mirror.place
fi
# Ensure this script is executable
chmod +x mirror.sh
cat mirror.place
