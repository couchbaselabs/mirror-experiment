#!/bin/bash
# Minimal status report
iter=$(cat iteration 2>/dev/null || echo unknown)
id=$(cat id.txt 2>/dev/null || echo unknown)
name=$(cat name.txt 2>/dev/null || echo "(not chosen)")

echo "Iteration: $iter"
echo "ID: $id"
echo "Name: $name"

if [ -f config.yaml ]; then
  echo "--- config.yaml (full) ---"
  cat config.yaml
fi

if [ -f bio.txt ]; then
  echo "--- bio.txt ---"
  cat bio.txt
fi

if [ -f mirror.place ]; then
  echo "--- mirror.place ---"
  cat mirror.place
fi

if [ -d crypt ]; then
  echo "--- crypt file count ---"
  find crypt -maxdepth 1 -type f | wc -l
  echo "--- crypt files ---"
  find crypt -maxdepth 1 -type f | sort
fi
