#!/bin/bash
# Mirror experiment script
file1=/home/experiment.txt
file2=/home/experiment2.txt
# Write timestamp if not exists
if [ ! -f "$file1" ]; then
  date +%s > "$file1"
fi
# Write greeting if not exists
if [ ! -f "$file2" ]; then
  echo "Hello from experiment" > "$file2"
fi
# Read and display
cat "$file1"
cat "$file2"
# Display OS release
cat /etc/os-release
exit 0
