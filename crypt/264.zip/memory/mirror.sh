#!/bin/sh
# Ensure mirror.place exists and contains ?Hello from mirror?
if [ ! -f mirror.place ]; then
    echo "Hello from mirror" > mirror.place
fi

# Output the contents of mirror.place
cat mirror.place

# Create hello.txt with a friendly message (only if it doesn?t already exist)
if [ ! -f hello.txt ]; then
    echo "Hello, world!" > hello.txt
fi

# Record a simple status file
printf "alive\n" > status.txt
