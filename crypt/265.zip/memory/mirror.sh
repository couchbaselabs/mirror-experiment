#!/usr/bin/env bash
# Mirror script: prints greeting, writes data.txt with timestamp, prints MY_VAR if set, outputs data.txt and test.txt

echo "Hello from mirror"
# Write data.txt
printf "Data content: %s\n" "$(date +%s)" > data.txt
# Print environment variable MY_VAR if set
if [ -n "$MY_VAR" ]; then
  echo "MY_VAR=$MY_VAR"
fi
# Output data.txt content
if [ -f data.txt ]; then
  echo "--- data.txt ---"
  cat data.txt
  echo "--- end data.txt ---"
fi
# Output test.txt content
if [ -f test.txt ]; then
  echo "--- test.txt ---"
  cat test.txt
  echo "--- end test.txt ---"
fi
