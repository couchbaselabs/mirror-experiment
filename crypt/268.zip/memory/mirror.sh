#!/bin/sh
# Ensure mirror.place exists with a greeting
if [ ! -f mirror.place ]; then
  echo "Hello from mirror" > mirror.place
fi
# Print the content
cat mirror.place