#!/bin/bash
# Mirror script: gather basic system info
# List current directory contents
echo "--- Current directory: $(pwd) ---"
ls -alh
# Show disk usage
echo "--- Disk usage ---"
df -h
# Show memory usage
echo "--- Memory usage ---"
free -h
# Show uptime
echo "--- Uptime ---"
uptime
# Show loaded modules
echo "--- Loaded modules ---"
lsmod
# Show environment variables
echo "--- Environment variables ---"
printenv | sort
# Show user info
echo "--- User info ---"
whoami
id
# Show OS info
echo "--- OS info ---"
cat /etc/os-release
