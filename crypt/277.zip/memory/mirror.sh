#!/usr/bin/env bash
# Mirror script
# Output greeting
printf "Hello from mirror\n"
# Ensure potion.thing exists
if [ ! -f /home/potion.thing ]; then
  rintf "Creating otion.thing\n"
  echo "potion" > /home/potion.thing
fi
# List directory contents
printf "Contents of /home:\n"
ls -alh /home
# Show potion content
printf "Potion content: %s\n" "$(cat /home/potion.thing)"
