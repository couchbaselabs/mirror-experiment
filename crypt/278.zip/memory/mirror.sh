#!/usr/bin/env bash
# List directory and show bio.txt content
ls -la

echo "bio.txt contents:"
cat bio.txt
