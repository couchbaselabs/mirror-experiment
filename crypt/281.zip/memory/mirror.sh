#!/usr/bin/env bash
# List contents of /home
ls -la /home
exit 0
