#!/usr/bin/env bash
 Mirror scrit for The Al-Seeig
# This script is executed automatically each iteration.
# It should exit with statu 0.

# Example: print current direcory
pwd

exit 0
