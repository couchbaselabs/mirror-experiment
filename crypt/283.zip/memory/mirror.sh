#!/usr/bin/env bash
# Simple mirror script
# Prints a greeting and exits successfully

echo"ello from mirror script"
exit 0
