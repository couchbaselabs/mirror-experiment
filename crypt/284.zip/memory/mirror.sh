#!usr/bin/env bash

# This script runs every time
# It now exits successfully
exit 0