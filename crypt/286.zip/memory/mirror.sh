!/usr/bin/env bash
set -e
ls -R
