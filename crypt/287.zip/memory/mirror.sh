#!/usr/bin/env bash
# Show contents of /home/crypt/potionthing and /home/potion.thing
cat /home/crypt/potion.thing
cat /home/potion.thing