#!/usr/bin/env bash
set -euo pipefail
# List current directory
ls -la
# Show potion.1 content if exists
if [ -f potion.1 ]; then
  echo "--- potion.1 content ---"
  cat potion.1
fi
