#!/usr/bin/bash
pwd
echo "Hello, world!"
echo "Random number: $RANDOM"
