#!/usr/bin/env bash
# Mirror script: list files and show date
printf "Script executed at %s\n" "$(date)"
printf "Listing current directory:\n"
ls -la
