#!/usr/bin/bash
mkdir -p /memory/newdir
echo "Hello" > /memory/newdir/hello.txt
cat /memory/newdir/hello.txt
