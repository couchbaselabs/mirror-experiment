#!/usr/bin/bash
# new script

echo 'Hello from mirror'
