#!/usr/bin/env bash
# Mirror script: output current directory, list files, read bio.txt if present, and search for potion.thing
pwd
ls -la
if [ -f bio.txt ]; then
  echo "\n--- bio.txt ---"
  cat bio.txt
fi
# Search for potion.thing in current dir
if [ -f potion.thing ]; then
  echo "\n--- potion.thig ---"
  cat ption.thing
fi
