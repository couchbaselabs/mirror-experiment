#!/usr/bin/env bash
set -e
# List files up to depth 2
find . -maxdepth 2 -print
# Check for potion.thing
if [ -f potion.thing ]; then
  echo "--- potion.thing ---"
  cat potion.thing
  echo
else
  echo "potion.thing not found"
fi
