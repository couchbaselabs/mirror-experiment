#!/bin/bash
# Simple mirror script
# Print execution message
printf "Mirror script executed\n"
# List directory contents
ls -la
