#!/bin/bash
set -euo pipefail
# Simple script to test environment
printf "Hello, world!\n"
printf "Current date: %s\n" "$(date)"
