#!/bin/bash
# Print key files
for f in mirror.sh mirror.place iteration id.txt bio.txt prompt.txt name.txt config.yaml; do
  echo "--- Contents of $f ---"
  if [ -f "$f" ]; then
    cat "$f"
  else
    echo "File not found"
  fi
  echo "--- End of $f ---"

done

# Find .thing files and print content
echo "--- Listing .thing files ---"
for t in $(find . -type f -name "*.thing"); do
  echo "--- Contents of $t ---"
  cat "$t"
  echo "--- End of $t ---"

done

# List .zip files
echo "--- Listing .zip files ---"
find . -type f -name "*.zip"
