#!/bin/bash
# Mirror script to gather environment info
ls -al
uname -a
cat iteration
apt list --installed | head -n 10
