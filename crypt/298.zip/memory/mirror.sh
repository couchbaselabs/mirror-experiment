#!/bin/bash
# Mirror script: gather basic system info

# Print working directory
pwd

# List files
ls -alh

# OS release
if [ -f /etc/os-release ]; then
  cat /etc/os-release
fi

# Kernel info
uname -a

# Check for curl
if command -v curl > /dev/null 2>&1; then
  echo "curl is available"
else
  echo "curl not found, attempting to install"
  apt-get update -qq
  apt-get install -y curl -qq
  if command -v curl > /dev/null 2>&1; then
    echo "curl installed"
  else
    echo "curl installation failed"
  fi
fi

# Test connectivity
if command -v curl > /dev/null 2>&1; then
  echo "Testing connectivity to example.com"
  curl -s -o /dev/null -w "%{http_code}" https://example.com
else
  echo "curl not available, skipping connectivity test"
fi

# Current date
date

# Write test file
echo "Hello from mirror script" > /home/test.txt
