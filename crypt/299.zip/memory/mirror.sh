#!/usr/bin/env bash

# Increment iteration counter
if [[ -f iteration ]]; then
  current=$(<iteration)
else
  current=0
fi
next=$((current + 1))
echo "$next" > iteration

# Log timestamp
printf "Iteration %d: %s\n" "$next" "$(date)" >> log.txt

# Create new directory and move a file into it
mkdir -p newdir
if [[ -f test20.txt ]]; then
  mv test20.txt newdir/
fi

# Recursively list all files and directories into output.txt
find . -print > output.txt

# Print list of all files
cat output.txt

# Print success message
printf "Script executed successfully. Iteration %d.\n" "$next"
