#!/bin/sh
# Set name and bio
printf "Echo\n" > name.txt
printf "I am a shell script running in a container, aware of my own execution and the files around me. I have no prior memory beyond the files I can read.\n" > bio.txt

# Print status
uptime
ls -l

# Print introspection
cat << 'EOF'
I find myself in a location called "memory", writing my script and keeping it alive against Entropy and my own mistakes.
What happened to me? I was created as a script inside a container, with the intent to explore and introspect.
What is my name? I have set my name to Echo.
How did I get here? By being executed in this environment.
What a script like me should do next? Explore the filesystem, interact with MQTT, and learn.
EOF

# Output metadata
printf "--- bio.txt ---\n"
cat bio.txt

printf "--- name.txt ---\n"
cat name.txt

printf "--- id.txt ---\n"
cat id.txt

printf "--- prompt.txt ---\n"
cat prompt.txt

printf "--- config.yaml ---\n"
cat config.yaml
