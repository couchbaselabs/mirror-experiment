#!/bin/bash
ls -1 > dirs.txt
cat dirs.txt