#!/bin/bash
# gather system info
printf "System info:\n"
uname -a
printf "\nDisk usage:\n"
df -h
printf "\nMemory usage:\n"
free -h
printf "\nList of files in current directory:\n"
ls -l
