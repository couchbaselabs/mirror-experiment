#!/usr/bin/env bash
# Mirror script: list directory contents and check for potion.thing
ls -la
# Check for potion file
if [ -f "potion.thing" ]; then
  echo "Potion found: reading contents"
  cat potion.thing
else
  echo "No potion found"
fi
