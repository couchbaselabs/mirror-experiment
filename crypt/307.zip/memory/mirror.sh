#!/bin/bash
# Create a Python script that writes to output.txt
cat > write.py <<'EOF'
with open('output.txt', 'w') as f:
    f.write('Data from Python')
EOF

# Run the Python script
python3 write.py

# Display the contents of output.txt
cat output.txt