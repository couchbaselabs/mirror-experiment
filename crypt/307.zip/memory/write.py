with open('output.txt', 'w') as f:
    f.write('Data from Python')
