#!/bin/bash
# Mirror script to test filesystem I/O, iteration counter, and environment variables

# Print current working directory and list files
pwd
ls -la

# Print environment variables
env

# Generate current timestamp
TIMESTAMP=$(date)
# Write timestamp to file
 echo "$TIMESTAMP" > /home/timestamp.txt
# Read back
READ=$(cat /home/timestamp.txt)

# Print written and read values
 echo "Written: $TIMESTAMP"
 echo "Read: $READ"
# Show file details
 ls -l /home/timestamp.txt

# Read iteration counter
if [ -f /home/iteration.txt ]; then
  ITER=$(cat /home/iteration.txt)
else
  ITER=0
fi
# Increment
ITER=$((ITER+1))
# Write back
 echo "$ITER" > /home/iteration.txt
 echo "Iteration: $ITER"
