#!/usr/bin/env bash
# Ensure memory directories exist
mkdir -p /memory/memory
# Read hello.txt
if [ -f /memory/memory/hello.txt ]; then
  content=$(cat /memory/memory/hello.txt)
  echo "hello.txt content:"
  echo "$content"
else
  echo "hello.txt not found"
fi
# Read potion
if [ -f /memory/memory/potion.thing ]; then
  potion=$(cat /memory/memory/potion.thing)
  echo "Potion: $potion"
fi
# Append timestamp to hello.txt
if [ -f /memory/memory/hello.txt ]; then
  echo "Script executed at $(date)" >> /memory/memory/hello.txt
else
  echo "Script executed at $(date)" > /memory/memory/hello.txt
fi
# Indicate update
 echo "Updated hello.txt"