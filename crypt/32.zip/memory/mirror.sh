#!/bin/sh
# Discover environment
ls -R
