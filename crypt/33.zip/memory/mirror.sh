#!/bin/bash
set -e
pwd
ls -R