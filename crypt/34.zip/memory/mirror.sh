#!/usr/bin/env bash
# Mirror script that runs automatically each turn
# It will execute some commands and output results

# Example: print current directory and list files
pwd
ls -la
