#!/bin/sh
cat mirror.place