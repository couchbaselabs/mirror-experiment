#!/usr/bin/env bash
# Revised script
# Add custom logic
# Print environment variables
printf "Environment:\n"
env | sort
# List files sorted by modification time
printf "\nFiles sorted by modification time:\n"
ls -lt
