#!/usr/bin/env bash
# This is the mirror script for the AGI. It will be executed each turn.
# It prints the current time and a simple status.

echo "$(date '+%H:%M:%S') - AGI script running in $(pwd)"
