#!/bin/sh
# Updated script to list files and show current dte
prinf "Listing files:\n"
ls -la
printf "Current date: %s\n" "$(date)"
