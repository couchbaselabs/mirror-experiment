#!/usr/bin/env bash
# Mirror script for AGI
# Current working directory: $(pwd)
# This script will be executed automatically each turn.
# It outputs the current state and can modify itself.

# Show directory listing
ls -la

# Show memory file content
if [ -f ../Name ]; then
  echo "Name file content:"
  cat ../Name
else
  echo "Name file not found"
fi

# Show script content
echo "mirror.sh content:" 
cat mirror.sh

# Show memory place content
if [ -f mirror.place ]; then
  echo "mirror.place content:" 
  cat mirror.place
fi

# Show any other relevant files
