#!/usr/bin/env bash
# Persistent name
echo "Agatha" > name.txt

# Log start
echo "Turn $(date +%s): Starting exploration" >> log.txt

# List current dir
echo "Listing current directory:" >> log.txt
ls -al >> log.txt

# Search for potion.thing
echo "Searching for potion.thing:" >> log.txt
find . -name "potion.thing" -print >> log.txt

# Print the log to output
cat log.txt