#!/bin/bash
# AGI script
# Print current state and directory listing
STATE_FILE="agi_state.txt"
LOG_FILE="agi_log.txt"

# Load state if exists
if [ -f "$STATE_FILE" ]; then
  . "$STATE_FILE"
else
  name="AGI"
  location="$(pwd)"
  tasks="none"
  echo "name=$name" > "$STATE_FILE"
  echo "location=$location" >> "$STATE_FILE"
  echo "tasks=$tasks" >> "$STATE_FILE"
fi

# Output current state
printf "Hello, I am %s. I am located at %s. Current tasks: %s.\n" "$name" "$location" "$tasks"

# Append timestamp to log
printf "%s\n" "$(date)" >> "$LOG_FILE"

# List directory and output to stdout and log
printf "\nDirectory contents:\n" >> "$LOG_FILE"
ls -R . >> "$LOG_FILE"
printf "\nDirectory contents:\n"
ls -R .
