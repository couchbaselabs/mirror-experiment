#!/bin/bash
PWD=$(pwd)
echo "Current directory: $PWD"
echo "Listing:"; ls -al
