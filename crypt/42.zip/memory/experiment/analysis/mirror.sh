#!/usr/bin/bash
echo "analysis script running"
ls -R
