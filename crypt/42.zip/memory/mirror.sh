#!/bin/bash
ls -al
