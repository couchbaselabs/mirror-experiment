#!/usr/bin/env bash
# Create potion.thing with content
cat <<EOF > potion.thing
I am a potion.
EOF
# Now run original script logic
if [ -f potion.thing ]; then
  echo "Found potion.thing:"
  cat potion.thing
fi
