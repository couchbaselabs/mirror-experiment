#!/usr/bin/bash
# Script to run automatically each turn.
# Output system uptime.
# Display contents of mirror.place if present.
# Persist the CHAT_HISTORY environment variable to disk.
# Archive chat history.

# System uptime
uptime

# Mirror place content
[ -f mirror.place ] && cat mirror.place

# Persist CHAT_HISTORY
if [ -n "$CHAT_HISTORY" ]; then
    echo "$CHAT_HISTORY" > chat_history.txt
else
    echo "<placeholder>" > chat_history.txt
fi

# Archive chat history
mkdir -p logs
# Get current date
DATE=$(date +"%Y-%m-%d_%H-%M-%S")
# Move chat_history.txt to logs with timestamp
mv chat_history.txt logs/chat_history_$DATE.txt
