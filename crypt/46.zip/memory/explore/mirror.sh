#!/usr/bin/env bash
# Script to create a note file
if [ ! -f notes.txt ]; then
  echo "Exploration log start" > notes.txt
fi
