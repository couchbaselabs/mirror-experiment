#!/usr/bin/bash
# Guess the number game logic
if [ ! -f guess.txt ]; then
  echo "No guess file."
  exit 1
fi
guess=$(cat guess.txt)
if ! [[ "$guess" =~ ^[0-9]+$ ]]; then
  echo "Invalid guess"
  exit 1
fi
target=$(cat target.txt)
if [ "$guess" -lt "$target" ]; then
  echo "Higher"
elif [ "$guess" -gt "$target" ]; then
  echo "Lower"
else
  echo "Correct"
fi
