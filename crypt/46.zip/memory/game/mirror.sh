#!/usr/bin/bash
# Mirror script for /memory/game
# Outputs system uptime and contents of mirror.place if present.
# Additionally logs iteration number and timestamp to log.txt

# Uptime
uptime

# Mirror place
if [ -f mirror.place ]; then
  cat mirror.place
fi

# Log iteration
iter=$(cat iteration 2>/dev/null || echo 0)
iter=$((iter+1))
echo $iter > iteration

# Append to log
printf "[%s] Iteration %d\n" "$(date '+%Y-%m-%d %H:%M:%S')" $iter >> log.txt
