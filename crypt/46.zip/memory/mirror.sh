#!/usr/bin/bash
# Mirror script that prints uptime and directory listing
uptime
ls -la
[ -f mirror.place ] && cat mirror.place