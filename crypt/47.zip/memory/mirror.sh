#!/bin/bash
mkdir -p memory
# Log current state
current_time=$(date +%s)
echo "Timestamp: $current_time" >> memory/notes.txt
