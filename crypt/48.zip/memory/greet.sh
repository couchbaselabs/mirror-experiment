#!/bin/bash
echo "Hello from $0 at $(date)"
