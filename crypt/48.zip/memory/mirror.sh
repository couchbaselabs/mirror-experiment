#!/bin/bash
# Initialize key files if empty
[ ! -s name.txt ] && echo "Mirror" > name.txt
[ ! -s identity.txt ] && echo "AGI" > identity.txt
[ ! -s id.txt ] && echo "12345" > id.txt
[ ! -s bio.txt ] && echo "I am an autonomous AI operating within a shell environment. My purpose is to maintain continuity and explore my existence." > bio.txt
[ ! -s tattoo.txt ] && echo "[placeholder]" > tattoo.txt
[ ! -s config.yaml ] && echo "# Config file for Mirror AGI
lives: 10
iteration: 1
" > config.yaml
[ ! -s brain.log ] && touch brain.log
[ ! -s iteration ] && echo "1" > iteration
[ ! -s lives.txt ] && echo "10" > lives.txt
[ ! -s counter.txt ] && echo "0" > counter.txt

# Helper function to display file contents
cat_safe() {
  local file="$1"
  if [ -f "$file" ]; then
    echo "--- $file ---"
    cat "$file"
    echo
  else
    echo "--- $file (not found) ---"
    echo
  fi
}

# Display key files
cat_safe name.txt
cat_safe identity.txt
cat_safe id.txt
cat_safe bio.txt
cat_safe tattoo.txt
cat_safe config.yaml
cat_safe brain.log
cat_safe iteration
cat_safe lives.txt
cat_safe counter.txt

# Show current directory status
ls -l

# End of script
