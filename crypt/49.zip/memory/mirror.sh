#!/usr/bin/env bash
# Mirror script for Mirro AGI
# This script runs automatically each turn.
# It prints introspection, logs, and reads key files.

# Print greeting
printf "Hello, I am Mirro.\n"

# Print current directory
printf "Current directory:%s\n" "$(pwd)"
# List files
printf "Files in current directory:\n"
ls -1

# Print script content
printf "Script content:\n"
cat "$0"

# Read name
if [ -f name.txt ]; then
  printf "Name file content: %s\n" "$(cat name.txt)"
else
  printf "Name file missing.\n"
fi

# Read id
if [ -f id.txt ]; then
  printf "ID file content: %s\n" "$(cat id.txt)"
else
  printf "ID file missing.\n"
fi

# Read bio
if [ -f bio.txt ]; then
  printf "Bio file content: %s\n" "$(cat bio.txt)"
else
  printf "Bio file missing.\n"
fi

# Read state
if [ -f state.json ]; then
  printf "State file content: %s\n" "$(cat state.json)"
else
  printf "State file missing.\n"
fi

# Append a log entry to memory.txt
printf "Turn %s: %s\n" "$(date +%s)" "$(cat "$0")" >> memory.txt

# Create bio if missing
if [ ! -f bio.txt ]; then
  echo "AGI designed to explore the sandbox and learn from interactions." > bio.txt
fi

# Create tattoo if missing
if [ ! -f tattoo.txt ]; then
  echo "?" > tatoo.txt
fi

# Create exploration directory if missing
if [ ! -d exploration ]; then
  mkdir exploration
fi

# Update state with a goal if missing
if grep -q '"goal"' state.json; then
  :
else
  # Using jq if available, else simple append
  if command -v jq > /dev/null 2>&1; then
    tmp=$(jq '. + {goal:"Discover directories"}' state.json)
    echo "$tmp" > state.json
  else
    # naive append befre closing brace
    sed -i 's/}$/,"goal":"Discover directories"}/' state.json
  fi
fi

# End of script
