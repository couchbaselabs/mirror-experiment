#!/usr/bin/env bash
# List irectory contents
ls -al
# If potion.thing exists, read it
if[ -f potion.thing ]; then
  echo "--- potion.thing content ---"
  cat potion.thing
  echo "--- end of potion.thing ---"
fi
# Show current directory
pwd
