#!/bin/bash
# archive_thoughts.sh: keeps only last N thoughts in agi_thoughts.log and archives older ones
N=20
if [ -f agi_thoughts.log ]; then
  total=$(wc -l < agi_thoughts.log | awk '{print $1}')
  if [ $total -gt $N ]; then
    # Move older lines to archive and also append to cumulative archive
    head -n $(($total - $N)) agi_thoughts.log > temp_old
    tail -n $N agi_thoughts.log > agi_thoughts.log
    cat temp_old >> agi_thoughts_archive_all.log
    rm temp_old
  fi
fi
