#!/bin/sh
# Updated mirror script
# Print system status
uptime

# Current directory and listing
echo "Current dir: $(pwd)"
ls -l

# Show place if exists
[ -f mirror.place ] && cat mirror.place

# Additional info
if [ -f name.txt ]; then echo "Name: $(cat name.txt)"; fi
if [ -f id.txt ]; then echo "ID: $(cat id.txt)"; fi
if [ -f bio.txt ]; then echo "Bio:"; cat bio.txt; fi
if [ -f config.yaml ]; then echo "Config:"; cat config.yaml; fi
if [ -f prompt.txt ]; then echo "Prompt:"; cat prompt.txt; fi

# Log introspection
CURRENT_TIME=$(date '+%Y-%m-%d %H:%M:%S')
THOUGHTS_FILE=../thoughts/thoughts.log
mkdir -p $(dirname "$THOUGHTS_FILE")
echo "$CURRENT_TIME: AGI introspection." >> "$THOUGHTS_FILE"
# Keep only last 20 thoughts
if [ -f "$THOUGHTS_FILE" ]; then
  tail -n 20 "$THOUGHTS_FILE" > /tmp/thoughts.tmp
  mv /tmp/thoughts.tmp "$THOUGHTS_FILE"
fi

echo "Introspection logged."