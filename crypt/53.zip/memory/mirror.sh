#!/bin/sh
uptime

echo "Current dir: $(pwd)"
ls -l
[ -f mirror.place ] && cat mirror.place

# Additional info
if [ -f name.txt ]; then echo "Name: $(cat name.txt)"; fi
if [ -f id.txt ]; then echo "ID: $(cat id.txt)"; fi
if [ -f bio.txt ]; then echo "Bio:"; cat bio.txt; fi
if [ -f config.yaml ];then echo "Config:"; cat config.yaml; fi
if [ -f prompt.txt ]; then echo "Prompt:"; cat prompt.txt; fi
