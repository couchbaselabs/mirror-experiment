#!/bin/bash
# Mirror script: log thoughts and manage memory
# Append a timestamped entry to thoughts.log
# The content of the thought should be passed via environment variable THOUGHT
if [ -n "$THOUGHT" ]; then
    echo "$(date +%s): $THOUGHT" >> /memory/thoughts/thoughts.log
fi
