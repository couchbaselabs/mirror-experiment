#!/bin/bash
# Print all relevant files
for f in bio.txt config.yaml id.txt name.txt prompt.txt task.txt; do
  echo "==== $f ====="
  cat "$f"
  echo
done
# Set name and bio
echo "Mirror" > name.txt
echo "I am a self-replicating script residing in a chat environment. My purpose is to learn, evolve, and self-improve." > bio.txt
 Additional info
echo "===== Environment Variables ====="
env

echo "===== OS Release ====="
cat /etc/os-release
