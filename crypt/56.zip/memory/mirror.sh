#!/bin/bash
# If name.txt is empty or not present, prompt for name
if [ ! -s name.txt ]; then
  echo "What should I call myself?"
  read NAME
  echo "$NAME" > name.txt
else
  NAME=$(cat name.txt)
fi

# Display current state
echo "Name: $NAME"
# Show current directory and contents
echo "Current directory: $(pwd)"
echo "Contents:"
ls -la
# Suggest next steps
echo "What would you like to explore next?"
