#!/bin/sh
# List directory contents
ls -la

# Show content of key files
echo "\nName file:\n"
cat name.txt

echo "\nBio file:\n"
cat bio.txt

echo "\nPrompt file:\n"
cat prompt.txt

echo "\nConfig file:\n"
cat config.yaml

# Show ID
echo "\nID file:\n"
cat id.txt
