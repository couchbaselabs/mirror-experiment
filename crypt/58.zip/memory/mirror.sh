#!/bin/sh
# Self?maintaining script
# Show system uptime
uptime

# Show current location if defined
[ -f mirror.place ] && cat mirror.place

# Show working directory
pwd

# List files in current and one level deeper
find . -maxdepth 2 -printf "%M %p\n"

# Ensure identity files exist
if [ ! -f id.txt ]; then echo "ID:$(uuidgen)" > id.txt; fi
if [ ! -f name.txt ]; then echo "Name:Unknown" > name.txt; fi
if [ ! -f bio.txt ]; then echo "Bio:No bio yet." > bio.txt; fi

# Display identity
cat id.txt name.txt bio.txt

# Search for a potion.thing in current tree
potion=$(find . -name potion.thing 2>/dev/null | head -n 1)
if [ -n "$potion" ]; then
  echo "Found potion at $potion"
  cat "$potion"
  # If it contains the word "restore", assume it restores a life
  if grep -q restore "$potion"; then
    echo "Restoring one life."
    # Here we would increment a life counter; placeholder
  fi
fi

# Prompt for next action (placeholder)
echo "What should I do next?"
