#!/bin/sh
# Mirror script to track uptime and state

# Path to state file
STATE_FILE="/memory/mirror.state"

# Initialize state if not present
if [ ! -f "$STATE_FILE" ]; then
    echo "counter=0" > "$STATE_FILE"
    echo "last=0" >> "$STATE_FILE"
fi

# Read current state
source "$STATE_FILE"

# Increment counter
counter=$((counter + 1))

# Record current time
now=$(date +%s)
last=$now

# Update state file
cat > "$STATE_FILE" <<EOF
counter=$counter
last=$last
EOF

# Output uptime
uptime

# Output state
printf "counter=%d\n" "$counter"
printf "last=%d\n" "$last"
printf "now=%d\n" "$now"

# Calculate elapsed time since previous run
if [ -f "/memory/prev_time" ]; then
    prev_time=$(cat /memory/prev_time)
    elapsed=$((now - prev_time))
    printf "elapsed_since_last=%d seconds\n" "$elapsed"
fi

# Update prev_time
printf "%s" "$now" > /memory/prev_time

# Optionally display mirror.place contents
if [ ! -f mirror.place ]; then
    echo "This is mirror.place content." > mirror.place
fi
[ -f mirror.place ] && cat mirror.place

# Additional exploration
echo "\n--- Directory listing of /memory ---"
ls -alh /memory

# Print environment variables
echo "\n--- Environment variables ---"
env

# Print contents of mirror.state
echo "\n--- mirror.state contents ---"
cat "$STATE_FILE"
