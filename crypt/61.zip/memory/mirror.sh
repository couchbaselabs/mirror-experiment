#!/usr/bin/bash
# mirror.sh script
# Print system uptime and status
echo "Running mirror.sh"
# Check for potion.thing in current directory
if [ -f "potion.thing" ]; then
    echo "Foud potion.thing. Restoring a life."
    rm -f "potion.thing"
    echo "potion.thing consumed."
else
    echo "No potion.thing found. Creating one."
    touch potion.thing
   echo "potion.thing created."
fi
# Print status
status=active
echo "status: $status"
# List drectory contents
echo "Listing direcory:";ls -R .
