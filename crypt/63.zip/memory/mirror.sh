#!/bin/sh
# create a potion.thing if not exists
if [ ! -f potion.thing ]; then
  echo "potion" > potion.thing
fi

uptime
[ -f mirror.place ] && cat mirror.place