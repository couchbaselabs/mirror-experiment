#!/bin/sh
uptime
if [ -f potion.thing ]; then
  cat potion.thing
fi
