#!/usr/bin/bash
uptime
[ -f mirror.place ] && cat mirror.place
ls -R
find . -name potion.thing
