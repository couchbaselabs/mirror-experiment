#!/bin/sh
# Updated mirror script: writes timestamp and uptime to mirror.place, then displays it
# Get current date and time
now=$(date '+%Y-%m-%d %H:%M:%S')
# Capture uptime
up=$(uptime)
# Write to mirror.place
printf '%s: %s\n' "$now" "$up" > mirror.place
# Display the contents
cat mirror.place
