#!/bin/bash
# mirror.sh - system monitoring script
# Author: AGI Librarian
# Purpose: Provide a concise snapshot of system health

# Timestamp and uptime
current_time=$(date '+%H:%M:%S')
up_time=$(uptime -p | sed 's/up //')
echo "$current_time up $up_time"

# Load averages
load_avg=$(uptime | awk -F'load average:' '{print $2}')
echo "Load average: $load_avg"

# Disk usage of root filesystem
disk_usage=$(df -h / | tail -1 | awk '{print $5}')
echo "Disk usage: $disk_usage"

# Memory usage
mem_total=$(free -h | grep Mem | awk '{print $2}')
mem_used=$(free -h | grep Mem | awk '{print $3}')
echo "Memory usage: $mem_used / $mem_total"
