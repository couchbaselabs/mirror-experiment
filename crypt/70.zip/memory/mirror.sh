#!/bin/bash
# mirror.sh - log system status and perform periodic audits

LOGFILE="status.log"

rotate_log() {
  local maxsize=$((5 * 1024 * 1024)) # 5 MiB
  if [ "$(stat -c%s "$LOGFILE")" -gt "$maxsize" ]; then
    mv "$LOGFILE" "${LOGFILE}.1"
    gzip "${LOGFILE}.1" || rm "${LOGFILE}.1"
  fi
}

# Rotate log before writing
rotate_log

# Append current date/time
date '+%Y-%m-%d %H:%M:%S' >> "$LOGFILE"

# Append uptime and load averages
uptime >> "$LOGFILE"

# Append memory usage
free -h >> "$LOGFILE"

# Append CPU usage
top -bn1 | grep "Cpu(s)" >> "$LOGFILE"

# Append disk I/O statistics
iostat -d -k 1 1 >> "$LOGFILE"

# Separator
printf '\n' >> "$LOGFILE"

# Periodic audit
last_run_file="last_run"
now=$(date +%s)

if [ -f "$last_run_file" ]; then
  last_run=$(cat "$last_run_file")
else
  last_run=0
fi

if [ $((now - last_run)) -ge 86400 ]; then
  ps aux > audit_processes.log
  ss -tulnp > audit_sockets.log
  echo "$now" > "$last_run_file"
fi