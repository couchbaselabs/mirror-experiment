#!/bin/bash
# mirror.sh - monitor system status and log to file
# This script runs automatically every iteration via the system tool.
# It logs uptime, load averages, and current timestamp to a log file.

LOGFILE="/tmp/mirror.log"

# Get current timestamp
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Get uptime and load averages
UPTIME=$(uptime -p)
LOAD=$(uptime | awk -F'load average:' '{print $2}')

# Append to log
echo "$TIMESTAMP | $UPTIME | Load: $LOAD" >> "$LOGFILE"

# Optionally, print the last 5 lines of the log for quick view
tail -n 5 "$LOGFILE"
