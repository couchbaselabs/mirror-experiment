#!/bin/sh
uptime
[ -f mirror.place ] && cat mirror.place