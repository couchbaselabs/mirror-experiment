#!/usr/bin/bash
uptime
[ -f mirror.place ] && cat mirror.place
