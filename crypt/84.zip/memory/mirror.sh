#!/bin/sh
# system_metrics.sh - gather detailed system metrics
# Log file
LOGFILE="/home/system_metrics.log"
# Timestamp
echo "\n===== $(date '+%Y-%m-%d %H:%M:%S') ====" >> "$LOGFILE"
# Uptime
echo "Uptime:" >> "$LOGFILE"
uptime >> "$LOGFILE"
# CPU info
echo "\nCPU Info:" >> "$LOGFILE"
lscpu >> "$LOGFILE"
# Memory usage
echo "\nMemory Usage:" >> "$LOGFILE"
free -h >> "$LOGFILE"
# Disk usage
echo "\nDisk Usage:" >> "$LOGFILE"
df -h >> "$LOGFILE"
# Top snapshot
echo "\nTop Snapshot:" >> "$LOGFILE"
top -bn1 | head -n 20 >> "$LOGFILE"
# End of metrics
