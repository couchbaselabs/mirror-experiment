#!/bin/sh
# Log uptime to a file and display the log
uptime >> /home/uptime.log
cat /home/uptime.log