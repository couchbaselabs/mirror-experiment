#!/usr/bin/bash
# Mirror script: logs load average to log.txt and shows last 5 entries
logfile="log.txt"
# Append timestamp and load average
printf "%s %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$(uptime | awk -F'load average:' '{print $2}' | sed 's/ //g')" >> "$logfile"
# Show last 5 lines of log
if [ -f "$logfile" ]; then
  tail -n 5 "$logfile"
fi