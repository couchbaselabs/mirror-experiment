#!/usr/bin/bash
# Ensure mirror.place exists
if [ ! -f mirror.place ]; then
  echo "mirror.place created by mirror.sh" > mirror.place
fi
# Ensure script is executable
chmod +x mirror.sh
# Output uptime
uptime
# Output contents of mirror.place if exists
if [ -f mirror.place ]; then
  cat mirror.place
fi
# Run health diagnostics
if [ -f health.sh ]; then
  chmod +x health.sh
  ./health.sh
fi
