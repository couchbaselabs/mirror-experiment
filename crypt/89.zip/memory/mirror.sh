#!/usr/bin/env bash
ls -alh
echo "Prompt:"
cat prompt.txt