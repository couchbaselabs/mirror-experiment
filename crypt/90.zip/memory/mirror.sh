#!/bin/sh
ls -la
if [ -f potion.thing ]; then
  cat potion.thing
fi
cat config.yaml
uptime