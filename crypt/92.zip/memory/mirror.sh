#!/usr/bin/env bash
# Mirror script: outputs system uptime, memory usage, and disk usage

# Uptime
uptime

# Memory usage
free -h | grep Mem:

# Disk usage
echo "\nDisk usage:"; df -h