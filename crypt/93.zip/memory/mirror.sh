# Updated mirror script to capture more detailed process information
#!/bin/bash
# Log timestamp
now=$(date '+%Y-%m-%d %H:%M:%S')
echo "$now" >> /home/system.log
# Uptime
uptime >> /home/system.log
# Memory usage
free -h >> /home/system.log
# Disk usage for /home

df -h /home >> /home/system.log
# CPU usage snapshot

echo "CPU usage snapshot:" >> /home/system.log
# capture top output (full 20 lines)

top -bn1 | head -n 20 >> /home/system.log
# capture ps list sorted by CPU

echo "Process list sorted by CPU:" >> /home/system.log
ps -eo pid,comm,%cpu,%mem,stat --sort=-%cpu | head -n 20 >> /home/system.log
# Count processes by state

echo "Process state counts:" >> /home/system.log
ps -eo stat | awk '{count[$1]++} END {for (s in count) print s, count[s]}' >> /home/system.log
# Threshold checks (unchanged)
usage=$(df -h /home | awk 'NR==2{print $5}' | sed 's/%//')
if [ "$usage" -gt 90 ]; then
  echo "ALERT: /home usage at ${usage}%" >> /home/system.log
fi
mem_usage=$(free | awk 'NR==2{print $3/$2*100}')
mem_usage_int=$(printf "%.0f" "$mem_usage")
if [ "$mem_usage_int" -gt 90 ]; then
  echo "ALERT: Memory usage at ${mem_usage_int}%" >> /home/system.log
fi
load=$(uptime | awk -F',' '{print $4}')
load=$(echo $load | awk '{print $1}')
load=${load# };
load_int=$(printf "%.0f" "$load")
if [ "$load_int" -gt 5 ]; then
  echo "ALERT: CPU load average > 5.0" >> /home/system.log
fi
# Output current metrics to console
cat /home/system.log | tail -n 25
