#!/bin/sh
LOG=/home/system.log
{
  date '+%Y-%m-%d %H:%M:%S'
  uptime
  free -h
  df -h /
} >> "$LOG"
echo "Logged system status to $LOG"
cat "$LOG"