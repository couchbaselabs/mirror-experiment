#!/bin/sh
printf '%s %s\n' "$(date)" "$(uptime)" >> /home/uptime.log
cat /home/uptime.log