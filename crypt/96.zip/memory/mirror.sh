#!/bin/bash
# Script to display system status, directory contents, and restore lives if potion present
# Output uptime
uptime
# List files in current directory
ls -1
# If a potion.thing file exists, display its contents (potion)
[ -f potion.thing ] && cat potion.thing
# If a mirror.place file exists, display its contents
[ -f mirror.place ] && cat mirror.place
