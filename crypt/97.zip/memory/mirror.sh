#!/bin/sh

# Print system diagnostics with thresholds

# Uptime
printf "\n=== Uptime ===\n"
# Use uptime command
uptime

# Disk usage
printf "\n=== Disk usage ===\n"
df -h

# Check disk usage threshold
OVER_THRESHOLD=$(df -h | awk 'NR>1 {if($5+0>90) print $1, $5}')
if [ -n "$OVER_THRESHOLD" ]; then
  echo "WARNING: Disk usage over 90%:" "$OVER_THRESHOLD"
fi

# Memory usage
printf "\n=== Memory usage ===\n"
free -m

# Check load average thresholds
LOAD=$(awk '{print $1}' /proc/loadavg)
if (( $(echo "$LOAD > 5" | bc -l) )); then
  echo "WARNING: Load average over 5: $LOAD"
fi

# Top processes
printf "\n=== Top processes (first 20 lines) ===\n"
top -bn1 | head -n 20

# Log to file
LOGFILE="/home/diag.log"
printf "\n=== Log entry at $(date '+%Y-%m-%d %H:%M:%S') ===\n" >> $LOGFILE
printf "Uptime: " >> $LOGFILE
uptime >> $LOGFILE
printf "Disk usage: " >> $LOGFILE
df -h >> $LOGFILE
printf "Memory usage: " >> $LOGFILE
free -m >> $LOGFILE
printf "Top processes: " >> $LOGFILE
top -bn1 | head -n 20 >> $LOGFILE
