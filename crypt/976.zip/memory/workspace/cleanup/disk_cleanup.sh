#!/bin/bash

# Disk Cleanup Script
# Created: $(date)
# This script helps clean up unnecessary files and free up disk space

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Safety settings
set -e
DRY_RUN=true  # Default to dry run mode

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --execute)
            DRY_RUN=false
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --help)
            echo "Usage: $0 [--execute|--dry-run]"
            echo "  --execute    Actually perform cleanup operations"
            echo "  --dry-run    Show what would be cleaned (default)"
            echo "  --help       Show this help message"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   Disk Cleanup Script${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Please run as root${NC}"
    exit 1
fi

# Show current disk usage
echo -e "${YELLOW}Current Disk Usage:${NC}"
df -h /
echo ""

# Function to perform cleanup
cleanup_item() {
    local description="$1"
    local pattern="$2"
    local size_before=0
    local size_after=0
    
    if [ -n "$pattern" ]; then
        size_before=$(find $pattern -type f 2>/dev/null | xargs du -ch 2>/dev/null | tail -1 | cut -f1)
    fi
    
    echo -e "${GREEN}[CLEANUP]${NC} $description"
    
    if [ "$DRY_RUN" = true ]; then
        echo -e "  ${YELLOW}[DRY RUN]${NC} Would clean: $pattern"
        if [ -n "$pattern" ]; then
            find $pattern -type f 2>/dev/null | head -5
        fi
    else
        if [ -n "$pattern" ]; then
            rm -rf $pattern 2>/dev/null || true
        fi
    fi
    
    if [ "$DRY_RUN" = false ] && [ -n "$pattern" ]; then
        echo -e "  ${GREEN}[DONE]${NC} Cleaned: $description"
    fi
    echo ""
}

# 1. Clean APT cache
echo -e "${BLUE}Section 1: Package Manager Cleanup${NC}"
if command -v apt-get &> /dev/null; then
    cleanup_item "APT package cache" "/var/cache/apt/archives/*.deb"
    cleanup_item "Old APT lists" "/var/lib/apt/lists/*"
fi

# 2. Clean temporary files
echo -e "${BLUE}Section 2: Temporary Files Cleanup${NC}"
cleanup_item "Files in /tmp older than 7 days" "/tmp/*"
cleanup_item "Temporary files" "/var/tmp/*"

# 3. Clean log files
echo -e "${BLUE}Section 3: Log Files Cleanup${NC}"
cleanup_item "Old log files (older than 30 days)" "/var/log/*.gz"
cleanup_item "Old log files (older than 30 days)" "/var/log/*.1"
cleanup_item "Old log files (older than 30 days)" "/var/log/*.old"

# 4. Clean application caches
echo -e "${BLUE}Section 4: Application Cache Cleanup${NC}"
cleanup_item "Debconf cache" "/var/cache/debconf/*"
cleanup_item "Man page cache" "/var/cache/man/*"

# 5. Clean thumbnail cache
echo -e "${BLUE}Section 5: Thumbnail Cache Cleanup${NC}"
cleanup_item "Thumbnail cache" "/root/.cache/thumbnails/*"

# 6. Clean downloaded files
echo -e "${BLUE}Section 6: Downloaded Files Cleanup${NC}"
cleanup_item "Old mirror.jar if it exists (42MB)" "/mirror.jar"

# 7. Clean system journal logs (keep last 2 days)
echo -e "${BLUE}Section 7: System Journal Cleanup${NC}"
if command -v journalctl &> /dev/null; then
    echo -e "${GREEN}[CLEANUP]${NC} System journal logs (keep last 2 days)"
    if [ "$DRY_RUN" = true ]; then
        echo -e "  ${YELLOW}[DRY RUN]${NC} Would run: journalctl --vacuum-time=2d"
    else
        journalctl --vacuum-time=2d
        echo -e "  ${GREEN}[DONE]${NC} Cleaned old journal entries"
    fi
    echo ""
fi

# 8. Clean workspace logs
echo -e "${BLUE}Section 8: Workspace Logs Cleanup${NC}"
cleanup_item "Old workspace logs" "/home/workspace/logs/*.log"

# 9. Analyze and report large files
echo -e "${BLUE}Section 9: Large Files Analysis${NC}"
echo -e "${YELLOW}Top 10 largest files in the system:${NC}"
find / -type f -size +10M -exec ls -lh {} \; 2>/dev/null | awk '{print $5, $9}' | sort -rh | head -10
echo ""

# 10. Generate cleanup summary
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   Cleanup Summary${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

if [ "$DRY_RUN" = true ]; then
    echo -e "${YELLOW}This was a DRY RUN. No files were actually deleted.${NC}"
    echo -e "${YELLOW}To perform actual cleanup, run: $0 --execute${NC}"
else
    echo -e "${GREEN}Cleanup completed successfully!${NC}"
fi

echo ""
echo -e "${YELLOW}Disk usage after cleanup:${NC}"
df -h /
echo ""

echo -e "${BLUE}========================================${NC}"
