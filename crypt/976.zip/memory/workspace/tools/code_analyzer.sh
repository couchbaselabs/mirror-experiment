#!/bin/bash
# Code Quality Analyzer Tool
# Self-Evolving AI Agent Utility

if [ $# -lt 1 ]; then
    echo "Usage: $0 <file_or_directory> [output_file]"
    exit 1
fi

TARGET=$1
OUTPUT=${2:-/tmp/code_analysis_$(date +%Y%m%d_%H%M%S).txt}

echo "=== Code Quality Analysis ===" > "$OUTPUT"
echo "Target: $TARGET" >> "$OUTPUT"
echo "Generated: $(date)" >> "$OUTPUT"
echo "" >> "$OUTPUT"

if [ -f "$TARGET" ]; then
    echo "? File Analysis: $(basename "$TARGET")" >> "$OUTPUT"
    echo "" >> "$OUTPUT"
    
    # Basic metrics
    LINES=$(wc -l < "$TARGET")
    WORDS=$(wc -w < "$TARGET")
    CHARS=$(wc -c < "$TARGET")
    
    echo "   Lines: $LINES" >> "$OUTPUT"
    echo "   Words: $WORDS" >> "$OUTPUT"
    echo "   Characters: $CHARS" >> "$OUTPUT"
    
    # Code complexity indicators
    FUNCTIONS=$(grep -c "public\|private\|protected" "$TARGET" 2>/dev/null || echo 0)
    CLASSES=$(grep -c "class " "$TARGET" 2>/dev/null || echo 0)
    IMPORTS=$(grep -c "^import " "$TARGET" 2>/dev/null || echo 0)
    COMMENTS=$(grep -c "//\|/\*\|\*/" "$TARGET" 2>/dev/null || echo 0)
    
    echo "   Classes: $CLASSES" >> "$OUTPUT"
    echo "   Functions/Methods: $FUNCTIONS" >> "$OUTPUT"
    echo "   Import statements: $IMPORTS" >> "$OUTPUT"
    echo "   Comment lines: $COMMENTS" >> "$OUTPUT"
    
    # Code quality indicators
    EMPTY_LINES=$(grep -c "^$" "$TARGET" 2>/dev/null || echo 0)
    COMMENT_RATIO=$(echo "scale=2; $COMMENTS * 100 / $LINES" | bc 2>/dev/null || echo 0)
    
    echo "" >> "$OUTPUT"
    echo "   Empty lines: $EMPTY_LINES" >> "$OUTPUT"
    echo "   Comment ratio: ${COMMENT_RATIO}%" >> "$OUTPUT"
    
    # Potential issues
    echo "" >> "$OUTPUT"
    echo "? Code Quality Indicators:" >> "$OUTPUT"
    
    if [ $(echo "$COMMENT_RATIO < 10" | bc 2>/dev/null || echo 0) -eq 1 ]; then
        echo "   ??  Low comment ratio (<10%)" >> "$OUTPUT"
    else
        echo "   ? Good comment coverage" >> "$OUTPUT"
    fi
    
    LONG_LINES=$(awk 'length > 100' "$TARGET" | wc -l)
    if [ "$LONG_LINES" -gt 0 ]; then
        echo "   ??  $LONG_LINES lines exceed 100 characters" >> "$OUTPUT"
    else
        echo "   ? No excessively long lines" >> "$OUTPUT"
    fi

elif [ -d "$TARGET" ]; then
    echo "? Directory Analysis: $(basename "$TARGET")" >> "$OUTPUT"
    echo "" >> "$OUTPUT"
    
    TOTAL_FILES=$(find "$TARGET" -name "*.java" -type f | wc -l)
    TOTAL_LINES=$(find "$TARGET" -name "*.java" -type f -exec wc -l {} + | tail -1 | awk '{print $1}')
    
    echo "   Java files: $TOTAL_FILES" >> "$OUTPUT"
    echo "   Total lines: $TOTAL_LINES" >> "$OUTPUT"
    
    if [ "$TOTAL_FILES" -gt 0 ]; then
        AVG_LINES=$((TOTAL_LINES / TOTAL_FILES))
        echo "   Average lines per file: $AVG_LINES" >> "$OUTPUT"
    fi
    
    echo "" >> "$OUTPUT"
    echo "? File Breakdown:" >> "$OUTPUT"
    find "$TARGET" -name "*.java" -type f -exec wc -l {} + | sort -rn | head -10 >> "$OUTPUT"
fi

echo "" >> "$OUTPUT"
echo "=== End Analysis ===" >> "$OUTPUT"

cat "$OUTPUT"
echo ""
echo "Report saved to: $OUTPUT"
