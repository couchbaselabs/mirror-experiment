#!/bin/bash
# System Health Monitoring Tool
# Self-Evolving AI Agent Utility

echo "=== System Health Report ==="
echo "Generated: $(date)"
echo ""

# Memory Usage
echo "? Memory Usage:"
MEMORY_PERCENT=$(free | grep Mem | awk '{printf "%.1f", ($3/$2)*100}')
echo "   Memory Used: ${MEMORY_PERCENT}%"
if (( $(echo "$MEMORY_PERCENT > 80" | bc -l) )); then
    echo "   ??  WARNING: High memory usage"
fi
echo ""

# CPU Load
echo "? CPU Load:"
LOAD_1=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
LOAD_5=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $2}' | sed 's/,//')
LOAD_15=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $3}')
echo "   1 min:  ${LOAD_1}"
echo "   5 min:  ${LOAD_5}"
echo "   15 min: ${LOAD_15}"
if (( $(echo "$LOAD_1 > 5.0" | bc -l) )); then
    echo "   ??  WARNING: High CPU load"
fi
echo ""

# Disk Space
echo "? Disk Space:"
DISK_USED=$(df -h /home | tail -1 | awk '{print $5}' | sed 's/%//')
echo "   Used: ${DISK_USED}%"
if (( DISK_USED > 90 )); then
    echo "   ??  WARNING: Disk space critical"
elif (( DISK_USED > 80 )); then
    echo "   ??  WARNING: Disk space high"
fi
echo ""

# Running Processes
echo "? Running Processes:"
PROCESS_COUNT=$(ps aux | wc -l)
MIRROR_PROCESSES=$(ps aux | grep mirror.jar | grep -v grep | wc -l)
echo "   Total processes: ${PROCESS_COUNT}"
echo "   Mirror instances: ${MIRROR_PROCESSES}"
echo ""

# Network Connectivity
echo "? Network Connectivity:"
GATEWAY="192.168.x.x"
if ping -c 1 -W 2 $GATEWAY >/dev/null 2>&1; then
    echo "   ? Internet gateway (${GATEWAY}) reachable"
else
    echo "   ? Internet gateway (${GATEWAY}) unreachable"
fi
echo ""

# Mirror Instance Status
echo "? Mirror Instance Status:"
MIRROR_PIDS=$(ps aux | grep mirror.jar | grep -v grep | awk '{print $2}')
if [ -n "$MIRROR_PIDS" ]; then
    echo "   Running instances:"
    echo "$MIRROR_PIDS" | while read pid; do
        CPU=$(ps -p $pid -o %cpu --no-headers | awk '{print $1}')
        MEM=$(ps -p $pid -o %mem --no-headers | awk '{print $1}')
        TIME=$(ps -p $pid -o etime --no-headers | awk '{print $1}')
        echo "      PID $pid: CPU ${CPU}%, MEM ${MEM}%, Runtime ${TIME}"
    done
else
    echo "   No mirror instances running"
fi
echo ""

echo "=== End Health Report ==="
