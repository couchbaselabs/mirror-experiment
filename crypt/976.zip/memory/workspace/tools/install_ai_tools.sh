#!/bin/bash

# Installation script for AI/ML development tools on Ubuntu 24.04
# Additional tools specifically for AI and machine learning development

set -e

echo "Installing AI/ML development tools..."

# Update package lists
sudo apt-get update

# Install Python scientific computing packages
echo "Installing Python scientific libraries..."
sudo apt-get install -y python3-numpy python3-scipy python3-matplotlib python3-pandas

# Install Jupyter and related tools
echo "Installing Jupyter and data science tools..."
sudo apt-get install -y jupyter-notebook python3-notebook

# Install machine learning libraries
echo "Installing ML libraries..."
sudo apt-get install -y python3-sklearn python3-torch python3-torchvision

# Install data visualization tools
sudo apt-get install -y python3-seaborn

# Install GPU support tools (NVIDIA)
echo "Checking for GPU support..."
if command -v nvidia-smi &> /dev/null; then
    echo "NVIDIA GPU detected, installing CUDA support..."
    sudo apt-get install -y nvidia-cuda-toolkit
else
    echo "No NVIDIA GPU detected, skipping CUDA tools"
fi

# Install virtual environment tools
echo "Installing Python environment tools..."
sudo apt-get install -y python3-venv python3-virtualenv

# Install additional AI development tools
echo "Installing additional AI tools..."
sudo apt-get install -y python3-tensorflow python3-keras 2>/dev/null || echo "TensorFlow not available in repos"

# Install model serving tools
sudo apt-get install -y python3-flask python3-fastapi

echo "AI/ML development tools installation complete!"
