#!/bin/bash

# Installation script for basic development tools on Ubuntu 24.04
# Essential tools for AI development and general development work

set -e

echo "Updating package lists..."
sudo apt-get update

echo "Installing essential internet tools..."
sudo apt-get install -y curl wget

echo "Installing version control..."
sudo apt-get install -y git

echo "Installing build essentials..."
sudo apt-get install -y build-essential cmake make

echo "Installing Python development tools..."
sudo apt-get install -y python3 python3-pip python3-venv python3-dev

echo "Installing Node.js and npm..."
sudo apt-get install -y nodejs npm

echo "Installing Docker..."
sudo apt-get install -y docker.io docker-compose

echo "Installing text editors..."
sudo apt-get install -y vim nano

echo "Installing system monitoring tools..."
sudo apt-get install -y htop iotop

echo "Installing JSON processor..."
sudo apt-get install -y jq

echo "Installing additional useful tools..."
sudo apt-get install -y unzip zip tar rsync

echo "Adding current user to docker group..."
sudo usermod -aG docker $USER

echo "Installation complete!"
echo "Note: You may need to log out and log back in for docker group changes to take effect."
