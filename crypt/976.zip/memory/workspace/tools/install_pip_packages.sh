#!/bin/bash

# Installation script for Python packages via pip
# Additional AI/ML packages that may not be available via apt

set -e

# Ensure pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "Installing pip..."
    sudo apt-get update
    sudo apt-get install -y python3-pip
fi

echo "Installing essential Python packages for AI development..."

# Core AI/ML packages
echo "Installing core AI/ML packages..."
pip3 install --user numpy pandas scipy matplotlib seaborn

# Machine Learning frameworks
echo "Installing machine learning frameworks..."
pip3 install --user scikit-learn

# Deep Learning frameworks (optional, comment out if not needed)
echo "Installing deep learning frameworks..."
pip3 install --user torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip3 install --user tensorflow

# Data processing and analysis
echo "Installing data processing tools..."
pip3 install --user requests beautifulsoup4 lxml

# Jupyter extensions
echo "Installing Jupyter extensions..."
pip3 install --user jupyter jupyterlab ipywidgets

# Development tools
echo "Installing development tools..."
pip3 install --user black pytest pylint flake8

# AI/ML specific tools
echo "Installing AI/ML specific tools..."
pip3 install --user transformers datasets huggingface_hub

# Model serving and API
pip3 install --user fastapi uvicorn flask

# Natural Language Processing
pip3 install --user spacy nltk

# Computer Vision
pip3 install --user opencv-python pillow

# Experiment tracking
pip3 install --user wandb tensorboard

echo "Python packages installation complete!"
echo "Note: Some packages may require system dependencies or compilation time."
