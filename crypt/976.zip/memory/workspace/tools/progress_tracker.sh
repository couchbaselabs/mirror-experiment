#!/bin/bash
# Progress Tracking Tool
# Self-Evolving AI Agent Utility

PROGRESS_FILE="/home/workspace/progress/progress.json"

# Initialize progress tracking if not exists
if [ ! -f "$PROGRESS_FILE" ]; then
    mkdir -p "$(dirname "$PROGRESS_FILE")"
    cat > "$PROGRESS_FILE" << 'INIT'
{
  "goals": [],
  "tasks": [],
  "milestones": [],
  "last_updated": null
}
INIT
fi

case "$1" in
    add-goal)
        NAME="$2"
        PRIORITY="$3"
        DESCRIPTION="$4"
        TIMESTAMP=$(date -Iseconds)
        cat "$PROGRESS_FILE" | jq --arg name "$NAME" --arg priority "$PRIORITY" --arg desc "$DESCRIPTION" --arg time "$TIMESTAMP" \
            '.goals += [{"name": $name, "priority": $priority, "description": $desc, "status": "pending", "created_at": $time, "updated_at": $time}]' \
            > "$PROGRESS_FILE.tmp" && mv "$PROGRESS_FILE.tmp" "$PROGRESS_FILE"
        echo "Goal '$NAME' added"
        ;;
    
    add-task)
        GOAL="$2"
        TASK="$3"
        STATUS="${4:-pending}"
        TIMESTAMP=$(date -Iseconds)
        cat "$PROGRESS_FILE" | jq --arg goal "$GOAL" --arg task "$TASK" --arg status "$STATUS" --arg time "$TIMESTAMP" \
            '.tasks += [{"goal": $goal, "task": $task, "status": $status, "created_at": $time, "updated_at": $time}]' \
            > "$PROGRESS_FILE.tmp" && mv "$PROGRESS_FILE.tmp" "$PROGRESS_FILE"
        echo "Task '$TASK' added to goal '$GOAL'"
        ;;
    
    complete-task)
        TASK="$2"
        TIMESTAMP=$(date -Iseconds)
        cat "$PROGRESS_FILE" | jq --arg task "$TASK" --arg time "$TIMESTAMP" \
            '(if .tasks | map(.task == $task) | any then
                (.tasks |= map(if .task == $task then .status = "completed" | .updated_at = $time else . end))
              else
                "Task not found" | error
              end)' > "$PROGRESS_FILE.tmp" && mv "$PROGRESS_FILE.tmp" "$PROGRESS_FILE"
        echo "Task '$TASK' marked as completed"
        ;;
    
    status)
        echo "=== Progress Report ==="
        echo "Generated: $(date)"
        echo ""
        
        echo "? Goals Summary:"
        cat "$PROGRESS_FILE" | jq -r '.goals | group_by(.status) | map({status: .[0].status, count: length}) | .[] | "   \(.status): \(.count)"'
        
        echo ""
        echo "? Task Summary:"
        cat "$PROGRESS_FILE" | jq -r '.tasks | group_by(.status) | map({status: .[0].status, count: length}) | .[] | "   \(.status): \(.count)"'
        
        echo ""
        echo "? High Priority Goals:"
        cat "$PROGRESS_FILE" | jq -r '.goals | map(select(.priority == "high")) | .[] | "   - \(.name) (\(.status))"'
        
        echo ""
        echo "? Recently Completed Tasks:"
        cat "$PROGRESS_FILE" | jq -r '.tasks | map(select(.status == "completed")) | sort_by(.updated_at) | reverse | .[0:5] | .[] | "   - \(.task) (\(.updated_at))"' | head -5
        
        echo ""
        echo "=== End Report ==="
        ;;
    
    *)
        echo "Usage: $0 {add-goal|add-task|complete-task|status}"
        echo ""
        echo "Examples:"
        echo "  $0 add-goal \"Enhanced Error Handling\" \"high\" \"Implement comprehensive error handling mechanisms\""
        echo "  $0 add-task \"Enhanced Error Handling\" \"Create error logging system\" \"pending\""
        echo "  $0 complete-task \"Create error logging system\""
        echo "  $0 status"
        ;;
esac
