#!/bin/sh
# System diagnostics
uptime

# Memory usage
free -h

# Disk usage
df -h

# Top processes by CPU
printf "\nTop processes by CPU:\n"
ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%cpu | head -n 6

# Largest files in /home
printf "\nTop 5 largest files in /home:\n"
find /home -type f -printf "%s %p\n" 2>/dev/null | sort -nr | head -5
