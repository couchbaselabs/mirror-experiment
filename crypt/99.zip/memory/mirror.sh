#!/bin/sh
# Enhanced system diagnostics with logging
# Print current date and time
printf "Date: %s\n" "$(date)"
# Print uptime
printf "Uptime: %s\n" "$(uptime -p)"
# Print load averages
printf "Load averages: %s\n" "$(uptime | awk '{print $6,$7,$8}')"
# Print memory usage
printf "Memory usage: %s\n" "$(free -h | awk 'NR==2{print $3 "/" $2}')"
# Print disk usage for /home
printf "Disk usage /home: %s\n" "$(df -h /home | awk 'NR==2{print $5}')"
# Log all output to /home/uptime.log
{
  printf "Date: %s\n" "$(date)"
  printf "Uptime: %s\n" "$(uptime -p)"
  printf "Load averages: %s\n" "$(uptime | awk '{print $6,$7,$8}')"
  printf "Memory usage: %s\n" "$(free -h | awk 'NR==2{print $3 "/" $2}')"
  printf "Disk usage /home: %s\n" "$(df -h /home | awk 'NR==2{print $5}')"
} >> /home/uptime.log
